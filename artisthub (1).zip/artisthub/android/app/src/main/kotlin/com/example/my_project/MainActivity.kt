package com.cygnus.artisthub

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
