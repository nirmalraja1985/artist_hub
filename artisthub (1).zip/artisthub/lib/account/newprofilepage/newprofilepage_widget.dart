import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/componant/comment/comment_widget.dart';
import '/componant/newsnipeimage/newsnipeimage_widget.dart';
import '/componant/postsetting/postsetting_widget.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_toggle_icon.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_video_player.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import 'newprofilepage_model.dart';
export 'newprofilepage_model.dart';

class NewprofilepageWidget extends StatefulWidget {
  const NewprofilepageWidget({
    Key? key,
    this.userss,
  }) : super(key: key);

  final UserRecord? userss;

  @override
  _NewprofilepageWidgetState createState() => _NewprofilepageWidgetState();
}

class _NewprofilepageWidgetState extends State<NewprofilepageWidget>
    with TickerProviderStateMixin {
  late NewprofilepageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  final animationsMap = {
    'iconOnActionTriggerAnimation': AnimationInfo(
      trigger: AnimationTrigger.onActionTrigger,
      applyInitialState: true,
      effects: [
        ScaleEffect(
          curve: Curves.elasticOut,
          delay: 0.ms,
          duration: 750.ms,
          begin: Offset(0.0, 0.0),
          end: Offset(1.0, 1.0),
        ),
        ScaleEffect(
          curve: Curves.easeOut,
          delay: 900.ms,
          duration: 450.ms,
          begin: Offset(1.0, 1.0),
          end: Offset(0.0, 0.0),
        ),
      ],
    ),
  };

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => NewprofilepageModel());

    setupAnimations(
      animationsMap.values.where((anim) =>
          anim.trigger == AnimationTrigger.onActionTrigger ||
          !anim.applyInitialState),
      this,
    );
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () => _model.unfocusNode.canRequestFocus
          ? FocusScope.of(context).requestFocus(_model.unfocusNode)
          : FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: Colors.white,
        body: SafeArea(
          top: true,
          child: SingleChildScrollView(
            controller: _model.columnController1,
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                SingleChildScrollView(
                  controller: _model.coverimage,
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Stack(
                        children: [
                          if (valueOrDefault(
                                      currentUserDocument?.coverPhotoUrl, '') !=
                                  null &&
                              valueOrDefault(
                                      currentUserDocument?.coverPhotoUrl, '') !=
                                  '')
                            AuthUserStreamWidget(
                              builder: (context) => Container(
                                width: MediaQuery.sizeOf(context).width * 1.0,
                                height:
                                    MediaQuery.sizeOf(context).height * 0.25,
                                decoration: BoxDecoration(
                                  color: FlutterFlowTheme.of(context)
                                      .secondaryBackground,
                                  image: DecorationImage(
                                    fit: BoxFit.cover,
                                    image: Image.network(
                                      valueOrDefault<String>(
                                        valueOrDefault(
                                            currentUserDocument?.coverPhotoUrl,
                                            ''),
                                        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRSEszdMiDor22NjwLfZoNu8JrthIbxVQrEJQ&usqp=CAU',
                                      ),
                                    ).image,
                                  ),
                                  borderRadius: BorderRadius.circular(15.0),
                                ),
                                child: Stack(
                                  children: [
                                    Align(
                                      alignment:
                                          AlignmentDirectional(0.01, 1.93),
                                      child: Container(
                                        width: 120.0,
                                        height: 120.0,
                                        decoration: BoxDecoration(
                                          color: FlutterFlowTheme.of(context)
                                              .secondaryBackground,
                                          image: DecorationImage(
                                            fit: BoxFit.cover,
                                            image: Image.network(
                                              valueOrDefault<String>(
                                                currentUserPhoto,
                                                'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBYWFRgWFhYYGRgaHBwcHRwcHCEaHh8eGSEcHh0aIxwhIS4lJB4rIxweJzgmKy8xNTU1ISQ7QDs0Py40NTEBDAwMEA8QHhISHzQrJCs0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NP/AABEIAREAuQMBIgACEQEDEQH/xAAbAAACAgMBAAAAAAAAAAAAAAAEBQIDAAEGB//EAEAQAAIBAgQDBQUGBQQBBAMAAAECEQAhAwQSMUFRYQUicYGREzKhsfAGUmLB0eEUQnKC8QcjkqIzFbLC8iTS4v/EABkBAAMBAQEAAAAAAAAAAAAAAAABAgMEBf/EACQRAAMBAAICAgICAwAAAAAAAAABEQIhMRJBA1EiMnGhE2GB/9oADAMBAAIRAxEAPwALDyoNytaVBqAA5zb650z9gvNuXHjVS4R3gwAfOK81s9MCVVJI09KniYKwbQAY24UaEaR3TFSEwTpAjeTA8ZpUGI8fSoLRsCRHGhBh6ECganMf/YngP802zQ1hmZSFUWHO4Hzt/ig8Zi5YmY5cyOHgP1q0xM5jtDDA5Ek8AY+rUHgYepiQLiAOUm5Pjcep8Q67UhF75ljuBcx93p405+zOQnLo5W7PiN5DSvL8NbeUzTFq6hzGY7OcHUohxBg21eHXhB34TQ5wYI4BwRB/lbgD6fCvSP4EPKsgNvrypfn/ALKqVOlmWeBuOY6giN96nPyfYPP0cI0Eq3X4kf8A81JBCO0d5mCL42J/OmWP2M6NETOkyNpU39axcoyKse8ATMT3m3aOY4Vp5IXixXniNS4aidIAMfeO9E4OSCjvCT4m1E5PIhOrHcm96JcHlQ9ekCz7YkzKxdYAPTl8fjVOAt7fKj82pB2sbHy40uxsOGsPhVLlEtQPwsLibRxiPlUM6jErhqJZ2Cr11GPmaAbEibGnv2MwTj5xNVxhK2Je9xAX0ZlPlRJyxN8Q6jtTLBETDWYlUHLSgv5FU+NBnB4xTbtNAcUcdCx0lzO3OFH/ACodcPu3H5Vztm2VwAHA+oqHZ2GpZ2b72heUJ73/AHJ9KYZhwiM5EhVJsOXD5UX2XgumGi6ASBcxuxuxvzYk0Xgc5B8NAbR5R4xU/aJ1+FMG17xc2tbapd/6NSOB7LQpVpmB0j65USygiSx8AedUKpuZ1H5VkykSUt93hzoHMu0kRI+UG58SfhtTBUa88hEfEUqzhcByCIAN9rgsB4CZNBSK83mP9tzAADBQLDYXJ5C9h0rmMbNA21LpGyrqaOpIF/Oie09XstBP84meTLAnzUmKX5UFFLmLe6Nojj48uW9b5ykiNPmFWewCq+6VJjfcc7bL4133YmXYZXLWs2GW/wCRUj86897WchApMsYLHqeHxr1TsrC1ZHKsJ/8ACk8rLq/+R9KrS/AzTmjeSQ6hamOJlwwig8A95aYloFZZ6Hrs5btLL9631ypJmsqZsK6nNMGM286UZnDmeVC1C5wIsTDIqhwaaZpLUudDNaJiaFubBgeI+cfI0izZafhXQ5lDB24fOkuZSQZ51thmOkK2c16Z/ph2bGDiYzA99go/pQGTPIliP7a8xcV7fksAZXJLh2V1RVjf/cc97fca3PlT+ZzM+zPCugFe+zMdmYkeAsv/AFC1b7G3nWlAGxIG3lwqQI5+INcdOuAeawdTommdTqT/AEp3z6lQPOnCgzeInptyj40BkO/juwjuKqeb95h5BUPnTR0MmIFxH1Bo0/QI1paSeEGB8vWs9k/3R61agJIFusj0qPs2/D6tSoEwrCYA6VQ2JaSIA5f4vRmHYbMeN/lQz4wgGDf9JpMaK1x5MelAYpU+0U3htr+J4fio1syoEmRytczyHp60E+ZYs1tAIHDUxtI6AxwuaSKQlzeGC7htwoczt3dj4QWtuZ86QsdbhYNzx5Mdz48uApn2j2gFx1AvpYFhNjYwk8Sb1aujCdG3EuHJ/ESE8tN63zUiNcs5DP4mtiWMfX0fOvYuzu08PCyOUw2bvrgoSP6gSR0gEia8d7SYSyxcGB4zb4UzymHi4yhyrsDC67m6BQw1dJX1Fba/UwSXkeo5DNYbsCDp435cKb5nE7o2Mg7V5fg9jY6DUmYCEj3WfTPntQ+F2vm8NoJZhN5GpfJlt8awWeOGaPvk7DGaDfn40PiPvves7Jf+IRnaVgwI47HfzrO0MPRh60uy7zy+oqJzDSguItjNrUiz3aWGkgGaBz2ex8c6VBVTYeHG/wASaqTBy2HGtsR8QgGwEQRII71wZF63zidmetfQNm+0ZBigPb6gedNHy6YikodptEHx6/KgsfLqqiBcSD4itctGWqWfZLI+3zmChErrDNaZXDl2HmBHmK9W7VTU6LuZLt1iwnxJJ/trkf8ASzIHVj48bBcNf7jqbzAVR/dXSZzFJdzIsdI8EsRf8Wqsvn1XPor4V7NonIcef6GhcQwWvEdb8/kaIUW2NtonyHLf8qXdpKPZmDdjpjoSQeO+gMfKsEqzYt7BxpQsZDOzMbQYJ7sxyXSPKm6ZgEiJMx04xypP2ZjgKSQR3iP+qk0xGaEEgEwY2nwPxFTrspLgOGZAPhY723q72nQ+lBp2gt54dKl/6gvJvSkKMNy06bmhcfHULqg8oHEnYDqdqu9oAIg+QoJ8YOyDSwjU1xEGwB/7GmxJEMFhMm7mxPAAfyr03HrQHaee7vdBMkAHm08D0vfoaLxsTUdCggyZjgs3PnsPPlQHaeYXvWspCIBtw1EeQ+VC7LOQ7SaGg+8TJjgbSfKAKcZrGBZkbZkQ+BCIfW0+vOghhe0xbA3NrdZbz39BWu0MTVjPpFgxHp3VHoK37iM3wK8ywDMd7kg8rQfPeu9+wmGG7McAXXMuJ4jUifDauIOGWAJU6SJnoTa/OZHiK7T/AEtx9WHmctyZMVRzBUq3oVS/WtHzloyfDTBT2HhpjNiYuD7ZSIIJgid7Dj14VBux0CucNCGe51ARcksSskEmw2AgWArv1TgbeN+dq2uRUnmPCsfLUiZT8bWjl/s12a662LaVZY03glSIYTfbUD/iOd+2GM4UIrGGMkc+IHh+ld/mZD92w0n5GuK+02HLieFLL/Lkr0DfZ/sw4ulhiaSkErAgkXuIv4bV0Oe7KMl1XD1kse6NNzadvgDA4RSXJLoh0Yg7W60z/wDUXuDp+t6etO8D8V7Obfs0YaGfeOo2tSPtQgE33ia6TtfNSDJ4G1c8uXOPi4eEN8R0WRw1bt5Az5Vr8dfLM9xLg9G+x+AMDIoSLsrYzRzcal89AShVe0GSeJ5nifMyad9rOFw9KiAzKoHQXI/4qRSFmg8vjWOteTbLwojeLjaRA3PwoDP4wDKmqdCExvdu6D4gBv8AlV+G+p9XAbTzP7UobF1l2j32gHoDpHyn1p5RQ67PxgNR37oY+YIt5CjcDNK+mAb3vY7T+lAZDGl4g7f+2/8A8qPTGAgxYz5ftWeiyZxFBFjB6Vn8b9TU0bUQADbna14+VTleZ9KkYyctG6jb63pfiM5OuNgQAOPT65Ux0AgmJpemEQSYWRMDrTZGSKs0u2nbruBNtvGkOa1zJWAthJmWAu3WeVOc0ze6ANTiOJA4k+k/ChM7hsXGx94+Q0x+VGeC0BdmZYrDMIISb7yxsfgb9KS59mJMAAcOpsCfhXS4+GWZipgBQOsBWk/GK57P4TARa1tulz8a0y6yNLgUrmcRRoFwx93f6P6Uw+yPahy2dw8QwFIKN/S5gf8AFgreANC9mnTjqWg9zECztrZHCT/cRS9jDnUN5BG2/wAr10Iw0qj2zBxNZPd3vvsbGjw9tzyrnexM8Xw0xOLLpci3fQlXt1IkdK3mu0gT7PWEHFidhx8zwrnsKlDyNRJGxEg7yCJFcl9p0KNNM+zvtXlRinBOJpVRCMwhdiNBbYRaDabDcXUfbDt/LK/ddcYmBpQhgN5JYSB4XO9NY1eg8kgLsjF9pKizjYHj4fpW85jMu9Jx2khIdIU/dm9uMwOfDkKLz/aK4qBtQ1bNw5wT9cKt5dKWuBXm8ySTTb/T/J68w2IdsJTH9Tyi/wDXWfIVzuYYjyr0D/T7IlcsHO+KzNy7q91R6q5/urR/jlmfekhh25iHWicArMehJCqfg9J8zjW0jc8fry+FFdq404uIxiF0oD0QSfRmf0pWiE98k32n5+O/rHCudI1RvO5j2eE5XcLA/qNhbxNKskxlBHGw6KD+cGpduYplEBndvSwB9T6VVk9W/dnatEvxFfyOgRm3C7QY1evDlTLAZzPd+N/ClWRLajysflTTCRwYEEcL7dDWGjVB2GzCDpk+P5xRWo8h6/tQiYjA96NjYc7RU/bPyT41IoFliR73Dpxpe+oTeWMAfnRxa21L2xhBYzy5m/H65UMSIOjQTMm0HjxmPrlVGd1e0EEQcNjy6f8A60WmKGtBA2U8LfvQOZxArqIMhXG39MbcN6EWWshDXO89fdAgepHpXP8AaOGQTN4APnebedOMziyZBNjMjkOPkT8KUZ3H1gmIJBkcjO3xt0IrTFJ0c7jiWCSFBdRqPCSJPlvQWd1BmBMmd/DjTBNOtWcEoHGoReBE28KDzmHpcqbxaunL5MNI6T7PdraMF0MkNpdY++IVx5qVP9ppfmM932YmWJgCbA8h0HPpS/srEKsyTuJE87bdYk+VT7HKnGhrcATzkfHak8JNsa1wkGYyF1hkRZ4j3hNpIHWTtVB7IQJq9qgJ2XUJMAXjauwzufbAgOAFIIkQRIixkERFIH+0qEmMNNUm+hfCYqc601wg1nN5EuJ2cDMMDttqMfCgQWRipNdnls1rQloA5ARXMdtxqnifyq8abcZGspKooZmxCqKJZmCqOZYwB6mvasDLrhYaqphMNVWeiKBM9QJryr7AZD2ucQm64YbEPitk89RU+Vem/ajMezyzncv3AvEl9lEXuJ8pqfm9ZQYd5OQdy5CHf3343cl9M+JnwA+9RPQULlsEot7sZLNzY7nw4DoBW8XF0KzkzpUn0ExWT+kbdCPPPqxHbkdI/st859aLyqGOFyfTlS3Bbu3k2meZ3NN8tAHH6itdcInPYyyKNq3i4M8xG1PcPCYzBHCPhSrItcWMx+lOcu5MQp4cPKubXZv6Clw5ABi3rW/ZdR6VoYnjIN6n7TxqSOQbHc6bEC17UtGO2kHmR8f3ozEwx93aP8UHrtZCNoHUX59KC8hmHib2IgD4z9etV5t5AeD3CG24EQ3/AFJ9KlhYsxY34kVj40wCvvW8j9GgIK0x5U2Nzp/M/Ok2cxtLzBhhHmNj8Y9Ka5cwsQbDfx3/ACpT2gZvcb/t8QK0yuRa6FL42kq8TpZXI5wQYqrOksVeI1y0cBqJMflRGuREHYfpWZ1QWfEw/wDxs7BQP5SNJIjkSxroRzsXBtLI4/lifj/ir2AZu4QOI+fzAqmdxFCsSveBiDHSqlJbh0q9o4mJhvhsisIsx3Gw8zY8t+lc8+VZSDzPLw/Wisr2yUkNDA87/XGo4ufVoGyrceOn/FCTz6Bta9hOP2gyoFHKfXjSLHxCxm5q7MZsn64cPkKpRJnl9Wq85hGtXg9O/wBLclpwsTGIu7BV/pTcjxZiP7aI7exji44EnRhSB1cwC3lG/wDSacZXBGUyaYd9Sqq2++41OwBtIOth1Arn8wgTufdsf6v5vjbqFFc29XTZrjPAO7Dnf64Uu7cxQMLT94/BTPzgedMFTmK57tnHl2W8KoHmTJ/IeVGFyXp8EcEQNibU6ywsLG4n0/zSzDeATpNv803yeNIAhgYvbansrI2yY4kHla52mmmHiQNjvyoXIudMxYDl+lGHEkxG/wDn9K5n2WyS40zM9Kl7X8LfXnVPtvwmqf4w/d+P7UChtsxYWnb48b1UMe1hvI8OvxFYuEOJN/H9aqRpkw0KCf8AjThaJ5bMRIIvPz325Vc+MoDFraR8waFZhwRt/WfOonEBBGho6+lKCNLiLpgfLmf3pF2gSQwABPLr9Cn0ALIUiLRte315UoxwJPcYbnYiYi5NXnsH0INdpjnbrMxNQzEKQqEkFVdhOztIY+gFFYy6QTpaCdrn65UuxnkxpNiB1uN/CRXSuTn1wD4jsHPjU8rBkMe4/dPQ7BvIkHyrWcwrtAI5eYH61TggXU+lX6I9gmLh6GIYTBgg9DcTXQZTsDCxAGV20nhv5c/8UszuFqhtz7reIgA+Yjzmr+xc2cNgpnSfnT0281PknOUtcrgZY/YWGgDXPjeal9m+zxjZzBw47gYM3LSnfPkYA86uz/aalYM3X4gnrTz/AE1yo/8AyMyRYAYY8hrxPUBR51mnqVmmkl0dJnsyWxDeBhiSLXckETxsdNvwNSHHA4j1p8iRhF2952LHhZZWfNi9Is0YJtN6532aZBHYCSYgda5LFxg7M17sDf8AE23lNPu2MSMNubQPK5PHkDXNo/eI6j4Xrb41xSNPkcYeIAsnlTjJZpDxtF7H0pLl390TaPlH6U1y2JxBjYbDfnS2jTDOg7PzSlQBI4bHh5UYuOh50qy2NE8B4D13oxMSbcug+XOudotoJOKvCdvH8qj7Qc6GbEi/P18Kj7c9KUCEjIi59KqcternbmaHc7kmmNGDEbhPw/SpYjNpIibfGhw9zc8CN/Mdam7GBB4b9b0QZN3PK0/O9LMwzHpNG4JbTFzFvIW9aX5lTzMATbjvVZXINgDqxB4bkfpSntIsoBEzPCJt+1OsRDBHET4fV6XZgQCxkiNvrzrbLMtLgCcGADMyP1oZsLvfXG1NccA35gR4AQPlQWMRWiZk0RCEC17Qeo5GqGwoO1viOlTD1bINMkDxWYCTtXq2RZcn2dgYRtiOvtHBOn3zrMnhA0KT5bkCuF7K7G9uwLnThKwBaNRY7+zUSJYg8wACOYBbfaPNO+M2okgjUonYCViwAPu22ilp1QEuaOPtBnGRssiNZhpa0hoIBsdrk+tCYvnP10pfnMx7TByr7+zxFRucMfePiwIpljLeBwrDShrliLtwkaRP8rnltpA+dIsGTie7wJ9LT8addug6lj7jfNaWYKHWOHdPxg/lW2P1J1+wyywOwAtP7Uyy7vvoEztNAYKNwi4nzFMMFHF5Ez6D1rPRpkY4DsLaeHPlbl5+lFo5i4il+GHi5Ez+XjzirvavJAA6fU1i0aBTuY2sJ/aq/afh+NRDtEW61GW6UDLRjA2FZ6RQWqas9ta4tTaCF/tLxIqT4kcuM0EuaA/l261ZgZpZPdPXaiCLzikSO7Pnxj96ExcXba9GriA8NxQL6Ykgwfyjr1oQA7vI4EbfrQOOecftRr4qbaT9edA5l12AM1pkjQCcUHUoNkJ0zxWTFCYxop1GpWGx1IfGxB+fpQOK1bIx0DO1MexMg2YxAimABqdonSg3PU8AOJI60udTXTdg9qYGDhae+zMZfSI/pWTwUH1JNPTi4EjqFyBKqmGAgw2DIp2UA6gW4klgJO5JY1z3b2AQoYqV0HSym5AFr+Gm55h+CzTfsz7S5fXpL6Jt3gVAja5tHnT7tXIpiKGd1RyIljCvEQDzNgJHADeFjJVPkbno897PxVh8JjCYi78mHuP4gqp/tjjNPMHMalvZhAYAgw0X8juDxBBpFncioLaNQUE2ZYC9Q2yry1QN7gWraF1ILhlt3XAkxcxqjQ67mJ8Lmq0qGXCfbxgqeGl19dJHwBpfI1i2/wBfnR+bLYqoQ+CYJg69BMqQRpcAg3BiTUFymNIPssTxADWtfuk8qFwgfYSrLAMHb5iT8qYKygCxv0oUO4sMPEtcykbz98gbE1LE7QhSFUM33dSkAdWTUo9azabNVpBa4iGwBkULj9q4a2TvEG/BQTzPOf5RJ6UsxcZ3sxn8KnSoB+828eMTyNH5HKKsM5BK7ACFX+kfnv4bUeKXYLTfQVks02ga170tMDYXgRO8AeZov2i/db0/eq1xFMwYi21z61L2qc/h+1SWUFoqDPUned6jvQUVa+u9EZYAkbkVioKIw8RRSbAJOIAI+uVBviLG5i/6cqKTEEULjNbapQhdmcdReW43A5eVAY2aSfePPY9Rypq7UvOEhcwqW3JWw5Wi5PKtcwjVAMRtUaQ5vPunlB4Vn8M7H3H3+6f0pk7qhBVRq4WA+A2FU+ykyxlhtyFX5GTQJidnOvvLp5SyqT4KSCfKo5fJlpIKiLEt8RETI6x40w9iXuzd0GxvEjkOJ8IHM1mcwkYbFiI5arbD7rD8J24GnRQCRMIe8Xxj91e4vmQZ/wC1MMDMYriBowk92ALkLYCwuOF6Wq8784nYA8iDdT4+RNWnMKF9m8jcapsZYtvw340MFAlMymExK4js885jwCyV9fKrcPFR5bSyOdyg0E9SohW8RBPOqcNVwkJUC15i/QDl4jnQj4mI41M4VTwU6if7ufhRBhmaxWQG40EXNmHnrBI+oJoBc0ASEBvuVUJ/7AD1uaKxMFihVpnSBfedAmeuqfSq+zz3F1gXWA3AwNv6gNwb2nahdC9kBgO0scO/3nadviKa5TIC2txe+lQQOM97fhwiiu5pPHpz/wA0SrobxsPDa8fGs9aZqsoqRVVYQKABNhAn9ev61aH1et+fOZrJQiwtx/KtYeKinyP6GoLN61EbdbHjHzqPtjyX68qmXX0H6VT7ROnwoAo1GpMIqC1OOdMokhrbNVUxWtVIArBxY8KtxXETQWFc1bi7UmgAc1jGeVK8TMGYUcbDl1J50fmhMmlzJysRwrXMMtFyEg9Tufyo7DVdMzI5c+ZY8unHw3V4WYizi3H9+XiKLxMIxrwyTxI3McyB7w6i/wA6poilOdzDMSimALGLG3ARsPSgzlt2nTR+HiI+40sfj4Hj4Vr2UE6njTBHU76uVvnHKqTnBLVNY4KAaj3oA/uYe7PEC0gzx6UPhQ0mO6dhwgcR0PKqnfW8CwMxwhf5j4nb15CidMDoPyo6Ds2isnunu/dbbyPD5dKIyagQ4UqdwDeOGoeWx9K1l8Ke8wtwU8fxEcuQ4+FiLmMR3OpTpAJgcyDct6bUux9BGQxSxxCx+6VHISwI8bCaLyOCWwAS2kMFjuuw94pqaQVBDAEaSCONBZNp1Np0sY1Rsd4PzoTLdpaFhQS8ASTYL71liNWr+YzFoA3ol6FYdDgYhIkpB3gxztBE2kEeVEa2F9ImefDnNLOyWLJrLG8RNrLO/OWLGaOgx7wJnnw2rHSjNsuou9o/BB/yH6Viu8To486oRybaqvTVxbbkaQzau22gbb8fDaty33R6iqiG+9fhe3WpaH+8fWgAcGrgbUOj1cDQyytzWBJqyRViOKVEbw0gVrFNq2zdapx2tQhgmZW1CnDsKJx2qJ2FaIjQG+GJg+tbyuTzAOrCR3Wf5QSs+I2ajMFELEvOlRJA3bkgPCTueAk0Xls9rb/fc4aAEIqCES3dEAju8zcn41T00uDOKgGJhB5JBR/5lYRP9S8CeY360vxlLkLJ3jnEb36fOKf57tFBhKhxFxXVjDLfShEadZ636eQoDMZ5GwkRMFEZdQ1i7Nq4tbgL7nYRFGdP6FpIH7OwgSzAQDED8IsPlPnRb4YDJInffmBIofK46KAFZTYCPdNhGzW+NFYpJAMEEGZiRsRwtx4Gm7QUguzmouYY90ggfmeZNbwcVTuHQngRKyfL8xV4ZpJbDVrbqxB9DA+NWK6ousBl3sxBvta2/Dc/CneBAmcxRhKQDLN0iAOO5vVXYT790MzCBP8AKOZPARM+nKtZHFV3ZnYBVuJ2P7Cn6sQqypmL+gkmlrXioGV5OkhhaVCqFACgDy2rChi0XufqK0WtdTIn68607R/Kefn1rE2NhG2t/mtsrdOPMVWmIIJ0nb1qSNJmCPGmBN9U7j0qHs35/XrUHY2Ok1Xr/C3150QDFq4NQ81jNTg6Ws5rSPQ5xK2r0QKHK9UYmJPhVReKg72oWQppnHHaukxuz0XERu8UUw7Mg0BNDsSkLdkVCTuS0eNcuFmmGP2gVxnfDYidUW4MukgqbbW9KGn6EG9j5XBGMExzqDA6GBAwzYwxJ3EiI4GxHAIM/knTEZHsymDM+vOONPOwMj/EYiYb+4pZ26r3dQ89IHmaPzGOmbZ1xgqPqIwnUbLsEfmOPmduKWmmTrNFGU+x7YjMyuowyisrExrdh7gXcXtfa3EwJZ/sPCVYXFDujBMRYARS4JEE7iUIJ6cNqaZTBYYehnj+HxVfvEhRJNoW57wJiDOqoZ7LZb/fU4gX2jk+4SAVLkcb7kdJo/yO8v8AoXiKX+yOKwYqUhSAJYqGJgwsyIgzJH7C9pdlvltGjFDhgZKSAGUwy8QQLXgb11GXXQuVnHUphvpgBm1piAQpUAwdMgEmAIvwpActltK4LZrHV1dirNhERqCqRZzaUBvTzvT7fH8C1lLoZ5XKYLZZcd2chWIxIUFy2wRSDA4GWJsb8gr7RyaZjDOJl2K6Cq4iNcqGsGBG+3mCeINEYeXnLYmE+JrT+Kw++JXUirDkAf0mOdE504OEmMmXLMcZl1FhCooJOlRAJA1EDpAkRSsfD5v/AAEr2hNkciiszAavdudlJAmBz2M/io5sVvu/GqssQojhzPHr4mthrSbW509OsrKiJDEa/d+PGoviP90etVviHhyt8KgcW0nx3ohRd7Ro9341FnYAW4nj41WX635T61sueZ6dacAkuK3EfH0FT9r0+NBPifU+prft/qf2o8RUiTUS1Vs1QLVcCl81pWofXU8M0QKE6q1qv4VWWqK2pQKXlq1NRm1QBuaIFH/2XzejMLPulWVjyETqPQEA1Zn3wNR9nqkzeRp+U+hpT2Zgh9WpgIA3nnfbiIkDiYovK4IOsEatMjUDsQGuJIkWm/AGs9ZVoUPxM0GDksNTJhT1ddE/I0vxsQsZN+Mm8k1e2EbQgGqwlr7GSRM/ynzBt/LQ5wW6cbyItM3mP5T6UkkgptcYDCKXnVqm3AQBQWJtHE28zR38E5+7xtqH4uv4TUcjhFgSFRrEDURINgTBvIDWgg7kzYVagmwsIq5ZQGWdc6QwLBQoAJWZ3mg9VGYqFj3WRdW4XuXXSpW4A3MwD6mDS97E8YJHjUpFFgNRLGDtVWqtFqqAS1dRWnc9KiWtsL1Q2J0ppAXoeoqZxPChleeArYaeVEJLXfwrftKoNosKj/aPWnABWaqy1bL1WWqxUmt6uAiqFepa6ALdd4ratQ6vxqYelApcz1Wj71XiPatYb2pwKXo8etHYWKQLH9Lf5+NDdk46Lio2KupFcF1jVK8RGxroV7RyhSPYwxTRqCggf7f/AJNM+/7U7/dHO1Rr+BoVvmCdzM+thG++xqaZxgDPe1cz+F1n/tPlTp3yzFXTAbRho2pdKd9GBVGLB5V9amW94crUIHT+JGIuCrYIGsoyKNOGrQ8qGgusMBq33io79AKsXGJF+AN7yZJN/U1HAxCsERN9+Zn5TT4ewfBRFwiX7pc6EBC4bqcaGBDzpMQTebAbgV8/lvZaQgLaEEHDAOsOCznFD6ypUEaY407/AKAX6qizVZ2lmEd9aKEBVJVRpGoIoeAOBaTQpemkFJF61qqlnravTgUtxGobEWasLTUSaaEaRRt+dW6tMCqC3StHGm0UQC5nnjUJHP41CTyrI6CnAoMTUNdV6jWpqyS5WvUi02mJqlaxzegA1sNQSA4I4Gqyw1qNQg7mNqo1WqotSgUJcgn3hbxE1tALXt0oQVcDRAL2ADEKZHOr9VtxQaNVjPak0Olq4g4m/iKsLr9EUv1Xq1zaiBS1sUefUipo5PL1pcaLwDanBUML8KwG1VLWTUwdNuKxDfeqWesJpwKEk9RVOJCtAJII3qLiq3aiAW8KqRDN6sisJoEaZ6j7SosvWs0imKgxrDWVlMCZqDb1lZQBZ+hoYVusoA2lX8/CsrKGCMG9TesrKQysb1N6yspgUDejMDYVusoYi3hWjWVlSMp41vE29PyrdZTAw1Wu4rKygZdUWrKygRA1usrKBH//2Q==',
                                              ),
                                            ).image,
                                          ),
                                          borderRadius:
                                              BorderRadius.circular(15.0),
                                          border: Border.all(
                                            color: Colors.white,
                                            width: 2.0,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          Align(
                            alignment: AlignmentDirectional(-1.00, -1.00),
                            child: FlutterFlowIconButton(
                              borderColor: Colors.transparent,
                              borderRadius: 20.0,
                              borderWidth: 1.0,
                              buttonSize: 60.0,
                              icon: Icon(
                                Icons.arrow_back,
                                color: FlutterFlowTheme.of(context).primaryText,
                                size: 24.0,
                              ),
                              onPressed: () async {
                                context.pushNamed('homepage');
                              },
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Align(
                      alignment: AlignmentDirectional(0.00, 0.00),
                      child: Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 60.0, 0.0, 0.0),
                        child: Container(
                          width: MediaQuery.sizeOf(context).width * 1.0,
                          height: 30.0,
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                          ),
                          child: Align(
                            alignment: AlignmentDirectional(0.00, 0.00),
                            child: AuthUserStreamWidget(
                              builder: (context) => Text(
                                valueOrDefault<String>(
                                  currentUserDisplayName,
                                  'Your Name',
                                ),
                                maxLines: 1,
                                style: FlutterFlowTheme.of(context)
                                    .bodyLarge
                                    .override(
                                      fontFamily: 'Readex Pro',
                                      fontSize: 20.0,
                                      fontWeight: FontWeight.w800,
                                    ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 8.0, 0.0, 0.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              AuthUserStreamWidget(
                                builder: (context) => Text(
                                  (currentUserDocument?.following?.toList() ??
                                          [])
                                      .length
                                      .toString(),
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Readex Pro',
                                        fontSize: 16.0,
                                        fontWeight: FontWeight.w600,
                                      ),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    5.0, 3.0, 0.0, 0.0),
                                child: Text(
                                  'Followers',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Readex Pro',
                                        fontSize: 12.0,
                                        fontWeight: FontWeight.w300,
                                      ),
                                ),
                              ),
                            ],
                          ),
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              StreamBuilder<List<UserRecord>>(
                                stream: queryUserRecord(
                                  queryBuilder: (userRecord) =>
                                      userRecord.where(
                                    'following',
                                    arrayContains: currentUserReference,
                                  ),
                                ),
                                builder: (context, snapshot) {
                                  // Customize what your widget looks like when it's loading.
                                  if (!snapshot.hasData) {
                                    return Center(
                                      child: SizedBox(
                                        width: 50.0,
                                        height: 50.0,
                                        child: CircularProgressIndicator(
                                          valueColor:
                                              AlwaysStoppedAnimation<Color>(
                                            FlutterFlowTheme.of(context)
                                                .primary,
                                          ),
                                        ),
                                      ),
                                    );
                                  }
                                  List<UserRecord> textUserRecordList =
                                      snapshot.data!;
                                  return Text(
                                    textUserRecordList.length.toString(),
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Readex Pro',
                                          fontSize: 16.0,
                                          fontWeight: FontWeight.w600,
                                        ),
                                  );
                                },
                              ),
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    5.0, 3.0, 0.0, 0.0),
                                child: Text(
                                  'Following',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Readex Pro',
                                        fontSize: 12.0,
                                        fontWeight: FontWeight.w300,
                                      ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                Align(
                  alignment: AlignmentDirectional(0.00, 0.00),
                  child: Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 5.0),
                    child: Container(
                      width: MediaQuery.sizeOf(context).width * 1.0,
                      height: 80.0,
                      decoration: BoxDecoration(
                        color: FlutterFlowTheme.of(context).secondaryBackground,
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              FFButtonWidget(
                                onPressed: () {
                                  print('Button pressed ...');
                                },
                                text: 'View Artist Profile',
                                icon: Icon(
                                  Icons.article,
                                  size: 20.0,
                                ),
                                options: FFButtonOptions(
                                  width: MediaQuery.sizeOf(context).width * 0.5,
                                  height: 30.0,
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      10.0, 0.0, 10.0, 0.0),
                                  iconPadding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 0.0, 0.0, 0.0),
                                  color: Color(0xFF0085FF),
                                  textStyle: FlutterFlowTheme.of(context)
                                      .titleSmall
                                      .override(
                                        fontFamily: 'Readex Pro',
                                        color: Colors.white,
                                        fontSize: 10.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                  elevation: 3.0,
                                  borderSide: BorderSide(
                                    color: Colors.transparent,
                                    width: 1.0,
                                  ),
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                            ],
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                5.0, 5.0, 5.0, 0.0),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 5.0, 0.0, 2.0),
                                  child: FutureBuilder<List<UserRecord>>(
                                    future: (_model
                                                .firestoreRequestCompleter ??=
                                            Completer<List<UserRecord>>()
                                              ..complete(queryUserRecordOnce(
                                                singleRecord: true,
                                              )))
                                        .future,
                                    builder: (context, snapshot) {
                                      // Customize what your widget looks like when it's loading.
                                      if (!snapshot.hasData) {
                                        return Center(
                                          child: SizedBox(
                                            width: 50.0,
                                            height: 50.0,
                                            child: CircularProgressIndicator(
                                              valueColor:
                                                  AlwaysStoppedAnimation<Color>(
                                                FlutterFlowTheme.of(context)
                                                    .primary,
                                              ),
                                            ),
                                          ),
                                        );
                                      }
                                      List<UserRecord> rowUserRecordList =
                                          snapshot.data!;
                                      // Return an empty Container when the item does not exist.
                                      if (snapshot.data!.isEmpty) {
                                        return Container();
                                      }
                                      final rowUserRecord =
                                          rowUserRecordList.isNotEmpty
                                              ? rowUserRecordList.first
                                              : null;
                                      return Row(
                                        mainAxisSize: MainAxisSize.max,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          if ((currentUserDocument?.following
                                                          ?.toList() ??
                                                      [])
                                                  .contains(widget
                                                      .userss?.reference) ==
                                              false)
                                            AuthUserStreamWidget(
                                              builder: (context) =>
                                                  FFButtonWidget(
                                                onPressed: () async {
                                                  await currentUserReference!
                                                      .update({
                                                    ...mapToFirestore(
                                                      {
                                                        'following': FieldValue
                                                            .arrayUnion([
                                                          widget
                                                              .userss?.reference
                                                        ]),
                                                      },
                                                    ),
                                                  });
                                                  setState(() => _model
                                                          .firestoreRequestCompleter =
                                                      null);
                                                  await _model
                                                      .waitForFirestoreRequestCompleted();
                                                },
                                                text: 'Following',
                                                options: FFButtonOptions(
                                                  height: 30.0,
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          24.0, 0.0, 24.0, 0.0),
                                                  iconPadding:
                                                      EdgeInsetsDirectional
                                                          .fromSTEB(0.0, 0.0,
                                                              0.0, 0.0),
                                                  color: Color(0xFF0691FF),
                                                  textStyle:
                                                      FlutterFlowTheme.of(
                                                              context)
                                                          .titleSmall
                                                          .override(
                                                            fontFamily:
                                                                'Readex Pro',
                                                            color: Colors.white,
                                                            fontSize: 12.0,
                                                          ),
                                                  elevation: 3.0,
                                                  borderSide: BorderSide(
                                                    color: Colors.transparent,
                                                    width: 1.0,
                                                  ),
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          8.0),
                                                ),
                                              ),
                                            ),
                                          if ((currentUserDocument?.following
                                                          ?.toList() ??
                                                      [])
                                                  .contains(widget
                                                      .userss?.reference) ==
                                              true)
                                            Padding(
                                              padding: EdgeInsetsDirectional
                                                  .fromSTEB(
                                                      15.0, 0.0, 0.0, 0.0),
                                              child: AuthUserStreamWidget(
                                                builder: (context) =>
                                                    FFButtonWidget(
                                                  onPressed: () async {
                                                    await currentUserReference!
                                                        .update({
                                                      ...mapToFirestore(
                                                        {
                                                          'following':
                                                              FieldValue
                                                                  .arrayRemove([
                                                            widget.userss
                                                                ?.reference
                                                          ]),
                                                        },
                                                      ),
                                                    });
                                                    setState(() => _model
                                                            .firestoreRequestCompleter =
                                                        null);
                                                    await _model
                                                        .waitForFirestoreRequestCompleted();
                                                  },
                                                  text: 'unfollow',
                                                  options: FFButtonOptions(
                                                    height: 30.0,
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(24.0, 0.0,
                                                                24.0, 0.0),
                                                    iconPadding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(0.0, 0.0,
                                                                0.0, 0.0),
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .primaryBtnText,
                                                    textStyle: FlutterFlowTheme
                                                            .of(context)
                                                        .titleSmall
                                                        .override(
                                                          fontFamily:
                                                              'Readex Pro',
                                                          color:
                                                              Color(0xFC000000),
                                                          fontSize: 12.0,
                                                        ),
                                                    elevation: 3.0,
                                                    borderSide: BorderSide(
                                                      color: Colors.transparent,
                                                      width: 1.0,
                                                    ),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            8.0),
                                                  ),
                                                ),
                                              ),
                                            ),
                                        ],
                                      );
                                    },
                                  ),
                                ),
                                Row(
                                  mainAxisSize: MainAxisSize.max,
                                  children: [
                                    Padding(
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          15.0, 0.0, 5.0, 0.0),
                                      child: FFButtonWidget(
                                        onPressed: () {
                                          print('Button pressed ...');
                                        },
                                        text: 'Message',
                                        icon: Icon(
                                          Icons.maps_ugc_sharp,
                                          color: Color(0xFF074DC8),
                                          size: 15.0,
                                        ),
                                        options: FFButtonOptions(
                                          width: 150.0,
                                          height: 30.0,
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  24.0, 0.0, 24.0, 0.0),
                                          iconPadding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  0.0, 0.0, 0.0, 0.0),
                                          color: FlutterFlowTheme.of(context)
                                              .primaryBtnText,
                                          textStyle:
                                              FlutterFlowTheme.of(context)
                                                  .titleSmall
                                                  .override(
                                                    fontFamily: 'Readex Pro',
                                                    color: Color(0xFC000000),
                                                    fontSize: 12.0,
                                                  ),
                                          elevation: 3.0,
                                          borderSide: BorderSide(
                                            color: Colors.transparent,
                                            width: 1.0,
                                          ),
                                          borderRadius:
                                              BorderRadius.circular(8.0),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    if (valueOrDefault(currentUserDocument?.bio, '') != null &&
                        valueOrDefault(currentUserDocument?.bio, '') != '')
                      Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            25.0, 0.0, 25.0, 15.0),
                        child: AuthUserStreamWidget(
                          builder: (context) => Text(
                            valueOrDefault(currentUserDocument?.bio, ''),
                            maxLines: 10,
                            style: FlutterFlowTheme.of(context).bodyMedium,
                          ),
                        ),
                      ),
                  ],
                ),
                Container(
                  width: MediaQuery.sizeOf(context).width * 1.0,
                  height: MediaQuery.sizeOf(context).height * 0.04,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      FFButtonWidget(
                        onPressed: () {
                          print('Button pressed ...');
                        },
                        text: 'Add story',
                        icon: Icon(
                          Icons.add,
                          size: 15.0,
                        ),
                        options: FFButtonOptions(
                          width: MediaQuery.sizeOf(context).width * 0.3,
                          height: 30.0,
                          padding: EdgeInsetsDirectional.fromSTEB(
                              10.0, 0.0, 10.0, 0.0),
                          iconPadding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 0.0, 0.0, 0.0),
                          color:
                              FlutterFlowTheme.of(context).secondaryBackground,
                          textStyle:
                              FlutterFlowTheme.of(context).titleSmall.override(
                                    fontFamily: 'Readex Pro',
                                    color: Color(0xFFC807C8),
                                    fontSize: 10.0,
                                    fontWeight: FontWeight.normal,
                                  ),
                          elevation: 3.0,
                          borderSide: BorderSide(
                            color: Colors.transparent,
                            width: 1.0,
                          ),
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                      ),
                      FFButtonWidget(
                        onPressed: () async {
                          context.pushNamed('neweditprofile');
                        },
                        text: 'Edit profile',
                        icon: FaIcon(
                          FontAwesomeIcons.pen,
                          color: Colors.black,
                          size: 15.0,
                        ),
                        options: FFButtonOptions(
                          width: MediaQuery.sizeOf(context).width * 0.3,
                          height: 30.0,
                          padding: EdgeInsetsDirectional.fromSTEB(
                              10.0, 0.0, 10.0, 0.0),
                          iconPadding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 0.0, 0.0, 0.0),
                          color: Color(0xFFF1F1F1),
                          textStyle:
                              FlutterFlowTheme.of(context).titleSmall.override(
                                    fontFamily: 'Readex Pro',
                                    color: Colors.black,
                                    fontSize: 10.0,
                                    fontWeight: FontWeight.normal,
                                  ),
                          elevation: 3.0,
                          borderSide: BorderSide(
                            color: Colors.transparent,
                            width: 1.0,
                          ),
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                      ),
                      Builder(
                        builder: (context) => FFButtonWidget(
                          onPressed: () async {
                            _model.currentPageLink =
                                await generateCurrentPageLink(
                              context,
                              isShortLink: false,
                            );

                            await Share.share(
                              _model.currentPageLink,
                              sharePositionOrigin:
                                  getWidgetBoundingBox(context),
                            );
                          },
                          text: 'Share profile',
                          icon: FaIcon(
                            FontAwesomeIcons.share,
                            color: Color(0xFF0091FF),
                            size: 15.0,
                          ),
                          options: FFButtonOptions(
                            width: MediaQuery.sizeOf(context).width * 0.3,
                            height: 30.0,
                            padding: EdgeInsetsDirectional.fromSTEB(
                                10.0, 0.0, 10.0, 0.0),
                            iconPadding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 0.0, 0.0, 0.0),
                            color: Color(0xFFF1F1F1),
                            textStyle: FlutterFlowTheme.of(context)
                                .titleSmall
                                .override(
                                  fontFamily: 'Readex Pro',
                                  color: Colors.black,
                                  fontSize: 10.0,
                                  fontWeight: FontWeight.normal,
                                ),
                            elevation: 3.0,
                            borderSide: BorderSide(
                              color: Colors.transparent,
                              width: 1.0,
                            ),
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 15.0, 0.0, 0.0),
                  child: Container(
                    width: MediaQuery.sizeOf(context).width * 1.0,
                    height: MediaQuery.sizeOf(context).height * 0.2,
                    decoration: BoxDecoration(
                      color: Colors.black,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              15.0, 0.0, 0.0, 0.0),
                          child: Text(
                            'Are you an artist Dreaming of becoming an artist in the future?',
                            textAlign: TextAlign.center,
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Raleway',
                                  color: Color(0xFFFEB600),
                                  fontSize: 18.0,
                                  fontWeight: FontWeight.bold,
                                ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              10.0, 10.0, 10.0, 0.0),
                          child: Text(
                            'Is popularity, fame, income generation, talent show, creativity your goal?',
                            textAlign: TextAlign.center,
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Readex Pro',
                                  color: Colors.white,
                                  fontWeight: FontWeight.w300,
                                ),
                          ),
                        ),
                        Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 15.0, 0.0, 0.0),
                              child: FFButtonWidget(
                                onPressed: () {
                                  print('Button pressed ...');
                                },
                                text: 'Join Artist Hub',
                                icon: Icon(
                                  Icons.add,
                                  size: 15.0,
                                ),
                                options: FFButtonOptions(
                                  width: MediaQuery.sizeOf(context).width * 0.5,
                                  height: 30.0,
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      10.0, 0.0, 10.0, 0.0),
                                  iconPadding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 0.0, 0.0, 0.0),
                                  color: Color(0xFF0085FF),
                                  textStyle: FlutterFlowTheme.of(context)
                                      .titleSmall
                                      .override(
                                        fontFamily: 'Readex Pro',
                                        color: Colors.white,
                                        fontSize: 10.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                  elevation: 3.0,
                                  borderSide: BorderSide(
                                    color: Colors.transparent,
                                    width: 1.0,
                                  ),
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                Align(
                  alignment: AlignmentDirectional(-1.00, 0.00),
                  child: Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(25.0, 15.0, 25.0, 0.0),
                    child: Container(
                      width: MediaQuery.sizeOf(context).width * 1.0,
                      height: MediaQuery.sizeOf(context).height * 0.035,
                      decoration: BoxDecoration(
                        color: Color(0xFFE4E4E4),
                        boxShadow: [
                          BoxShadow(
                            blurRadius: 2.0,
                            color: Color(0x33000000),
                            offset: Offset(0.0, 1.0),
                          )
                        ],
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                15.0, 0.0, 0.0, 0.0),
                            child: Text(
                              'Basic Info',
                              style: FlutterFlowTheme.of(context)
                                  .labelLarge
                                  .override(
                                    fontFamily: 'Readex Pro',
                                    color: Colors.black,
                                    fontWeight: FontWeight.w600,
                                  ),
                            ),
                          ),
                          InkWell(
                            splashColor: Colors.transparent,
                            focusColor: Colors.transparent,
                            hoverColor: Colors.transparent,
                            highlightColor: Colors.transparent,
                            onTap: () async {
                              context.pushNamed('neweditprofile');
                            },
                            child: Container(
                              width: 40.0,
                              height: 40.0,
                              decoration: BoxDecoration(
                                color: Color(0xFFD7D7D7),
                                shape: BoxShape.circle,
                              ),
                              child: Align(
                                alignment: AlignmentDirectional(0.00, 0.00),
                                child: FaIcon(
                                  FontAwesomeIcons.pen,
                                  color: Colors.black,
                                  size: 15.0,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding:
                      EdgeInsetsDirectional.fromSTEB(25.0, 10.0, 25.0, 0.0),
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Row(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Container(
                            width: 40.0,
                            height: 40.0,
                            decoration: BoxDecoration(
                              color: Color(0xFFEFECEC),
                              shape: BoxShape.circle,
                            ),
                            child: Icon(
                              Icons.person_2,
                              color: Colors.black,
                              size: 24.0,
                            ),
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                20.0, 0.0, 0.0, 0.0),
                            child: Column(
                              mainAxisSize: MainAxisSize.max,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                AuthUserStreamWidget(
                                  builder: (context) => Text(
                                    valueOrDefault(
                                        currentUserDocument?.gender, ''),
                                    maxLines: 1,
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Readex Pro',
                                          fontSize: 14.0,
                                        ),
                                  ),
                                ),
                                Text(
                                  'Gender',
                                  maxLines: 1,
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Readex Pro',
                                        fontSize: 8.0,
                                        fontWeight: FontWeight.w300,
                                      ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      Opacity(
                        opacity: 0.5,
                        child: SizedBox(
                          width: 280.0,
                          child: Divider(
                            thickness: 1.0,
                            color: Color(0xCC000000),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                if (dateTimeFormat('yMMMd', currentUserDocument?.birthday) !=
                        null &&
                    dateTimeFormat('yMMMd', currentUserDocument?.birthday) !=
                        '')
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(25.0, 10.0, 25.0, 0.0),
                    child: AuthUserStreamWidget(
                      builder: (context) => Column(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Container(
                                width: 40.0,
                                height: 40.0,
                                decoration: BoxDecoration(
                                  color: Color(0xFFEFECEC),
                                  shape: BoxShape.circle,
                                ),
                                child: Icon(
                                  Icons.cake_rounded,
                                  color: Colors.black,
                                  size: 24.0,
                                ),
                              ),
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    20.0, 0.0, 0.0, 0.0),
                                child: Column(
                                  mainAxisSize: MainAxisSize.max,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      dateTimeFormat('yMMMd',
                                          currentUserDocument!.birthday!),
                                      maxLines: 1,
                                      style: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .override(
                                            fontFamily: 'Readex Pro',
                                            fontSize: 14.0,
                                          ),
                                    ),
                                    Text(
                                      'Birthday',
                                      maxLines: 1,
                                      style: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .override(
                                            fontFamily: 'Readex Pro',
                                            fontSize: 8.0,
                                            fontWeight: FontWeight.w300,
                                          ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          Opacity(
                            opacity: 0.5,
                            child: SizedBox(
                              width: 280.0,
                              child: Divider(
                                thickness: 1.0,
                                color: Color(0xCC000000),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                if (valueOrDefault(currentUserDocument?.nationalty, '') !=
                        null &&
                    valueOrDefault(currentUserDocument?.nationalty, '') != '')
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(25.0, 10.0, 25.0, 0.0),
                    child: AuthUserStreamWidget(
                      builder: (context) => Column(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Container(
                                width: 40.0,
                                height: 40.0,
                                decoration: BoxDecoration(
                                  color: Color(0xFFEFECEC),
                                  shape: BoxShape.circle,
                                ),
                                child: Icon(
                                  Icons.flag_circle_outlined,
                                  color: Colors.black,
                                  size: 24.0,
                                ),
                              ),
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    20.0, 0.0, 0.0, 0.0),
                                child: Column(
                                  mainAxisSize: MainAxisSize.max,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      valueOrDefault(
                                          currentUserDocument?.nationalty, ''),
                                      maxLines: 1,
                                      style: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .override(
                                            fontFamily: 'Readex Pro',
                                            fontSize: 14.0,
                                          ),
                                    ),
                                    Text(
                                      'Nationality',
                                      maxLines: 1,
                                      style: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .override(
                                            fontFamily: 'Readex Pro',
                                            fontSize: 8.0,
                                            fontWeight: FontWeight.w300,
                                          ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          Opacity(
                            opacity: 0.5,
                            child: SizedBox(
                              width: 280.0,
                              child: Divider(
                                thickness: 1.0,
                                color: Color(0xCC000000),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                if (valueOrDefault(currentUserDocument?.currentCity, '') !=
                        null &&
                    valueOrDefault(currentUserDocument?.currentCity, '') != '')
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(25.0, 10.0, 25.0, 0.0),
                    child: AuthUserStreamWidget(
                      builder: (context) => Column(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Container(
                                width: 40.0,
                                height: 40.0,
                                decoration: BoxDecoration(
                                  color: Color(0xFFEFECEC),
                                  shape: BoxShape.circle,
                                ),
                                child: Icon(
                                  Icons.location_city_sharp,
                                  color: Colors.black,
                                  size: 24.0,
                                ),
                              ),
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    20.0, 0.0, 0.0, 0.0),
                                child: Column(
                                  mainAxisSize: MainAxisSize.max,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      valueOrDefault(
                                          currentUserDocument?.currentCity, ''),
                                      maxLines: 1,
                                      style: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .override(
                                            fontFamily: 'Readex Pro',
                                            fontSize: 14.0,
                                          ),
                                    ),
                                    Text(
                                      'Current city',
                                      maxLines: 1,
                                      style: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .override(
                                            fontFamily: 'Readex Pro',
                                            fontSize: 8.0,
                                            fontWeight: FontWeight.w300,
                                          ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          Opacity(
                            opacity: 0.5,
                            child: SizedBox(
                              width: 280.0,
                              child: Divider(
                                thickness: 1.0,
                                color: Color(0xCC000000),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                Align(
                  alignment: AlignmentDirectional(-1.00, 0.00),
                  child: Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(25.0, 15.0, 25.0, 0.0),
                    child: Container(
                      width: MediaQuery.sizeOf(context).width * 1.0,
                      height: MediaQuery.sizeOf(context).height * 0.035,
                      decoration: BoxDecoration(
                        color: Color(0xFFE4E4E4),
                        boxShadow: [
                          BoxShadow(
                            blurRadius: 2.0,
                            color: Color(0x33000000),
                            offset: Offset(0.0, 1.0),
                          )
                        ],
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                10.0, 0.0, 0.0, 0.0),
                            child: Text(
                              'Contact Info',
                              style: FlutterFlowTheme.of(context)
                                  .labelLarge
                                  .override(
                                    fontFamily: 'Readex Pro',
                                    color: Colors.black,
                                    fontWeight: FontWeight.w600,
                                    fontStyle: FontStyle.italic,
                                  ),
                            ),
                          ),
                          InkWell(
                            splashColor: Colors.transparent,
                            focusColor: Colors.transparent,
                            hoverColor: Colors.transparent,
                            highlightColor: Colors.transparent,
                            onTap: () async {
                              context.pushNamed('neweditprofile');
                            },
                            child: Container(
                              width: 40.0,
                              height: 40.0,
                              decoration: BoxDecoration(
                                color: Color(0xFFD7D7D7),
                                shape: BoxShape.circle,
                              ),
                              child: Align(
                                alignment: AlignmentDirectional(0.00, 0.00),
                                child: FaIcon(
                                  FontAwesomeIcons.pen,
                                  color: Colors.black,
                                  size: 15.0,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                if (currentPhoneNumber != null && currentPhoneNumber != '')
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(25.0, 10.0, 25.0, 0.0),
                    child: AuthUserStreamWidget(
                      builder: (context) => Column(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Container(
                                width: 40.0,
                                height: 40.0,
                                decoration: BoxDecoration(
                                  color: Color(0xFFEFECEC),
                                  shape: BoxShape.circle,
                                ),
                                child: Icon(
                                  Icons.call_rounded,
                                  color: Colors.black,
                                  size: 24.0,
                                ),
                              ),
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    20.0, 0.0, 0.0, 0.0),
                                child: Column(
                                  mainAxisSize: MainAxisSize.max,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      currentPhoneNumber,
                                      maxLines: 1,
                                      style: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .override(
                                            fontFamily: 'Readex Pro',
                                            fontSize: 14.0,
                                          ),
                                    ),
                                    Text(
                                      'Mobile',
                                      maxLines: 1,
                                      style: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .override(
                                            fontFamily: 'Readex Pro',
                                            fontSize: 8.0,
                                            fontWeight: FontWeight.w300,
                                          ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          Opacity(
                            opacity: 0.5,
                            child: SizedBox(
                              width: 280.0,
                              child: Divider(
                                thickness: 1.0,
                                color: Color(0xCC000000),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                if (valueOrDefault(currentUserDocument?.homePhoneNumber, '') !=
                        null &&
                    valueOrDefault(currentUserDocument?.homePhoneNumber, '') !=
                        '')
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(25.0, 10.0, 25.0, 0.0),
                    child: AuthUserStreamWidget(
                      builder: (context) => Column(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Container(
                                width: 40.0,
                                height: 40.0,
                                decoration: BoxDecoration(
                                  color: Color(0xFFEFECEC),
                                  shape: BoxShape.circle,
                                ),
                                child: Icon(
                                  Icons.call,
                                  color: Colors.black,
                                  size: 24.0,
                                ),
                              ),
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    20.0, 0.0, 0.0, 0.0),
                                child: Column(
                                  mainAxisSize: MainAxisSize.max,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      valueOrDefault(
                                          currentUserDocument?.homePhoneNumber,
                                          ''),
                                      maxLines: 1,
                                      style: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .override(
                                            fontFamily: 'Readex Pro',
                                            fontSize: 14.0,
                                          ),
                                    ),
                                    Text(
                                      'Home',
                                      maxLines: 1,
                                      style: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .override(
                                            fontFamily: 'Readex Pro',
                                            fontSize: 8.0,
                                            fontWeight: FontWeight.w300,
                                          ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          Opacity(
                            opacity: 0.5,
                            child: SizedBox(
                              width: 280.0,
                              child: Divider(
                                thickness: 1.0,
                                color: Color(0xCC000000),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                if (currentUserEmail != null && currentUserEmail != '')
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(25.0, 10.0, 25.0, 0.0),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Row(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            Container(
                              width: 40.0,
                              height: 40.0,
                              decoration: BoxDecoration(
                                color: Color(0xFFEFECEC),
                                shape: BoxShape.circle,
                              ),
                              child: Icon(
                                Icons.email,
                                color: Colors.black,
                                size: 24.0,
                              ),
                            ),
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  20.0, 0.0, 0.0, 0.0),
                              child: Column(
                                mainAxisSize: MainAxisSize.max,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    currentUserEmail,
                                    maxLines: 1,
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Readex Pro',
                                          fontSize: 14.0,
                                        ),
                                  ),
                                  Text(
                                    'Email',
                                    maxLines: 1,
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Readex Pro',
                                          fontSize: 8.0,
                                          fontWeight: FontWeight.w300,
                                        ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        Opacity(
                          opacity: 0.5,
                          child: SizedBox(
                            width: 280.0,
                            child: Divider(
                              thickness: 1.0,
                              color: Color(0xCC000000),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                if (valueOrDefault(currentUserDocument?.website, '') != null &&
                    valueOrDefault(currentUserDocument?.website, '') != '')
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(25.0, 10.0, 25.0, 0.0),
                    child: AuthUserStreamWidget(
                      builder: (context) => Column(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Container(
                            width: MediaQuery.sizeOf(context).width * 0.85,
                            height: 50.0,
                            decoration: BoxDecoration(
                              color: FlutterFlowTheme.of(context)
                                  .secondaryBackground,
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  width: 40.0,
                                  height: 40.0,
                                  decoration: BoxDecoration(
                                    color: Color(0xFFEFECEC),
                                    shape: BoxShape.circle,
                                  ),
                                  child: Icon(
                                    Icons.webhook,
                                    color: Colors.black,
                                    size: 24.0,
                                  ),
                                ),
                                Expanded(
                                  child: Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        20.0, 0.0, 0.0, 0.0),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.max,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          valueOrDefault(
                                              currentUserDocument?.website, ''),
                                          maxLines: 2,
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Readex Pro',
                                                fontSize: 14.0,
                                              ),
                                        ),
                                        Text(
                                          'Website',
                                          maxLines: 1,
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Readex Pro',
                                                fontSize: 8.0,
                                                fontWeight: FontWeight.w300,
                                              ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Opacity(
                            opacity: 0.5,
                            child: SizedBox(
                              width: 280.0,
                              child: Divider(
                                thickness: 1.0,
                                color: Color(0xCC000000),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                if (valueOrDefault(currentUserDocument?.facebook, '') != null &&
                    valueOrDefault(currentUserDocument?.facebook, '') != '')
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(25.0, 10.0, 25.0, 0.0),
                    child: AuthUserStreamWidget(
                      builder: (context) => Column(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Container(
                            width: MediaQuery.sizeOf(context).width * 0.85,
                            height: 50.0,
                            decoration: BoxDecoration(
                              color: FlutterFlowTheme.of(context)
                                  .secondaryBackground,
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Container(
                                  width: 40.0,
                                  height: 40.0,
                                  decoration: BoxDecoration(
                                    color: Color(0xFFEFECEC),
                                    shape: BoxShape.circle,
                                  ),
                                  child: Icon(
                                    Icons.facebook_rounded,
                                    color: Colors.black,
                                    size: 24.0,
                                  ),
                                ),
                                Expanded(
                                  child: Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        20.0, 0.0, 0.0, 0.0),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.max,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          valueOrDefault(
                                              currentUserDocument?.facebook,
                                              ''),
                                          maxLines: 2,
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Readex Pro',
                                                fontSize: 14.0,
                                              ),
                                        ),
                                        Text(
                                          'Facebook',
                                          maxLines: 1,
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Readex Pro',
                                                fontSize: 8.0,
                                                fontWeight: FontWeight.w300,
                                              ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Opacity(
                            opacity: 0.5,
                            child: SizedBox(
                              width: 280.0,
                              child: Divider(
                                thickness: 1.0,
                                color: Color(0xCC000000),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                if (valueOrDefault(currentUserDocument?.youtube, '') != null &&
                    valueOrDefault(currentUserDocument?.youtube, '') != '')
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(25.0, 10.0, 25.0, 0.0),
                    child: AuthUserStreamWidget(
                      builder: (context) => Column(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Container(
                            width: MediaQuery.sizeOf(context).width * 0.85,
                            height: 50.0,
                            decoration: BoxDecoration(
                              color: FlutterFlowTheme.of(context)
                                  .secondaryBackground,
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Container(
                                  width: 40.0,
                                  height: 40.0,
                                  decoration: BoxDecoration(
                                    color: Color(0xFFEFECEC),
                                    shape: BoxShape.circle,
                                  ),
                                  child: Icon(
                                    Icons.ondemand_video_sharp,
                                    color: Colors.black,
                                    size: 24.0,
                                  ),
                                ),
                                Expanded(
                                  child: Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        20.0, 0.0, 0.0, 0.0),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.max,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          valueOrDefault(
                                              currentUserDocument?.youtube, ''),
                                          maxLines: 1,
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Readex Pro',
                                                fontSize: 14.0,
                                              ),
                                        ),
                                        Text(
                                          'YouTube',
                                          maxLines: 1,
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Readex Pro',
                                                fontSize: 8.0,
                                                fontWeight: FontWeight.w300,
                                              ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                Align(
                  alignment: AlignmentDirectional(-1.00, 0.00),
                  child: Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(25.0, 15.0, 25.0, 0.0),
                    child: Container(
                      width: MediaQuery.sizeOf(context).width * 1.0,
                      height: MediaQuery.sizeOf(context).height * 0.035,
                      decoration: BoxDecoration(
                        color: Color(0xFFE4E4E4),
                        boxShadow: [
                          BoxShadow(
                            blurRadius: 2.0,
                            color: Color(0x33000000),
                            offset: Offset(0.0, 1.0),
                          )
                        ],
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                15.0, 0.0, 0.0, 0.0),
                            child: Text(
                              'Education',
                              style: FlutterFlowTheme.of(context)
                                  .labelLarge
                                  .override(
                                    fontFamily: 'Readex Pro',
                                    color: Colors.black,
                                    fontWeight: FontWeight.w600,
                                  ),
                            ),
                          ),
                          InkWell(
                            splashColor: Colors.transparent,
                            focusColor: Colors.transparent,
                            hoverColor: Colors.transparent,
                            highlightColor: Colors.transparent,
                            onTap: () async {
                              context.pushNamed('neweditprofile');
                            },
                            child: Container(
                              width: 40.0,
                              height: 40.0,
                              decoration: BoxDecoration(
                                color: Color(0xFFD7D7D7),
                                shape: BoxShape.circle,
                              ),
                              child: Align(
                                alignment: AlignmentDirectional(0.00, 0.00),
                                child: FaIcon(
                                  FontAwesomeIcons.pen,
                                  color: Colors.black,
                                  size: 15.0,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                if (valueOrDefault(currentUserDocument?.college, '') != null &&
                    valueOrDefault(currentUserDocument?.college, '') != '')
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(25.0, 10.0, 25.0, 0.0),
                    child: AuthUserStreamWidget(
                      builder: (context) => Column(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Container(
                            width: MediaQuery.sizeOf(context).width * 0.85,
                            height: 50.0,
                            decoration: BoxDecoration(
                              color: FlutterFlowTheme.of(context)
                                  .secondaryBackground,
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Container(
                                  width: 40.0,
                                  height: 40.0,
                                  decoration: BoxDecoration(
                                    color: Color(0xFFEFECEC),
                                    shape: BoxShape.circle,
                                  ),
                                  child: Icon(
                                    Icons.house_outlined,
                                    color: Colors.black,
                                    size: 24.0,
                                  ),
                                ),
                                Expanded(
                                  child: Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        20.0, 0.0, 0.0, 0.0),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.max,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          valueOrDefault(
                                              currentUserDocument?.college, ''),
                                          maxLines: 2,
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Readex Pro',
                                                fontSize: 14.0,
                                              ),
                                        ),
                                        Text(
                                          'College',
                                          maxLines: 1,
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Readex Pro',
                                                fontSize: 8.0,
                                                fontWeight: FontWeight.w300,
                                              ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Opacity(
                            opacity: 0.5,
                            child: SizedBox(
                              width: 280.0,
                              child: Divider(
                                thickness: 1.0,
                                color: Color(0xCC000000),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                if (valueOrDefault(currentUserDocument?.highSchool, '') !=
                        null &&
                    valueOrDefault(currentUserDocument?.highSchool, '') != '')
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(25.0, 10.0, 25.0, 0.0),
                    child: AuthUserStreamWidget(
                      builder: (context) => Column(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Container(
                            width: MediaQuery.sizeOf(context).width * 0.85,
                            height: 50.0,
                            decoration: BoxDecoration(
                              color: FlutterFlowTheme.of(context)
                                  .secondaryBackground,
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Container(
                                  width: 40.0,
                                  height: 40.0,
                                  decoration: BoxDecoration(
                                    color: Color(0xFFEFECEC),
                                    shape: BoxShape.circle,
                                  ),
                                  child: Icon(
                                    Icons.home_outlined,
                                    color: Colors.black,
                                    size: 24.0,
                                  ),
                                ),
                                Expanded(
                                  child: Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        20.0, 0.0, 0.0, 0.0),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.max,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          valueOrDefault(
                                              currentUserDocument?.highSchool,
                                              ''),
                                          maxLines: 5,
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Readex Pro',
                                                fontSize: 14.0,
                                              ),
                                        ),
                                        Text(
                                          'High School',
                                          maxLines: 1,
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Readex Pro',
                                                fontSize: 8.0,
                                                fontWeight: FontWeight.w300,
                                              ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Opacity(
                            opacity: 0.5,
                            child: SizedBox(
                              width: 280.0,
                              child: Divider(
                                thickness: 1.0,
                                color: Color(0xCC000000),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                if (valueOrDefault(currentUserDocument?.univercity, '') !=
                        null &&
                    valueOrDefault(currentUserDocument?.univercity, '') != '')
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(25.0, 10.0, 25.0, 0.0),
                    child: AuthUserStreamWidget(
                      builder: (context) => Column(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Container(
                            width: MediaQuery.sizeOf(context).width * 0.85,
                            height: 50.0,
                            decoration: BoxDecoration(
                              color: FlutterFlowTheme.of(context)
                                  .secondaryBackground,
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Container(
                                  width: 40.0,
                                  height: 40.0,
                                  decoration: BoxDecoration(
                                    color: Color(0xFFEFECEC),
                                    shape: BoxShape.circle,
                                  ),
                                  child: Icon(
                                    Icons.school_sharp,
                                    color: Colors.black,
                                    size: 24.0,
                                  ),
                                ),
                                Expanded(
                                  child: Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        20.0, 0.0, 0.0, 0.0),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.max,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          valueOrDefault(
                                              currentUserDocument?.univercity,
                                              ''),
                                          maxLines: 2,
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Readex Pro',
                                                fontSize: 14.0,
                                              ),
                                        ),
                                        Text(
                                          'University',
                                          maxLines: 1,
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Readex Pro',
                                                fontSize: 8.0,
                                                fontWeight: FontWeight.w300,
                                              ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Opacity(
                            opacity: 0.5,
                            child: SizedBox(
                              width: 280.0,
                              child: Divider(
                                thickness: 1.0,
                                color: Color(0xCC000000),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                if (valueOrDefault(currentUserDocument?.eduOther, '') != null &&
                    valueOrDefault(currentUserDocument?.eduOther, '') != '')
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(25.0, 10.0, 25.0, 0.0),
                    child: AuthUserStreamWidget(
                      builder: (context) => Column(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Container(
                            width: MediaQuery.sizeOf(context).width * 0.85,
                            height: 100.0,
                            decoration: BoxDecoration(
                              color: FlutterFlowTheme.of(context)
                                  .secondaryBackground,
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Container(
                                  width: 40.0,
                                  height: 40.0,
                                  decoration: BoxDecoration(
                                    color: Color(0xFFEFECEC),
                                    shape: BoxShape.circle,
                                  ),
                                  child: Icon(
                                    Icons.psychology,
                                    color: Colors.black,
                                    size: 24.0,
                                  ),
                                ),
                                Expanded(
                                  child: Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        20.0, 0.0, 0.0, 0.0),
                                    child: SingleChildScrollView(
                                      controller: _model.columnController2,
                                      child: Column(
                                        mainAxisSize: MainAxisSize.max,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            valueOrDefault(
                                                currentUserDocument?.eduOther,
                                                ''),
                                            maxLines: 15,
                                            style: FlutterFlowTheme.of(context)
                                                .bodyMedium
                                                .override(
                                                  fontFamily: 'Readex Pro',
                                                  fontSize: 14.0,
                                                  fontWeight: FontWeight.w300,
                                                ),
                                          ),
                                          Text(
                                            'Other',
                                            maxLines: 1,
                                            style: FlutterFlowTheme.of(context)
                                                .bodyMedium
                                                .override(
                                                  fontFamily: 'Readex Pro',
                                                  fontSize: 8.0,
                                                  fontWeight: FontWeight.w300,
                                                ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                Align(
                  alignment: AlignmentDirectional(-1.00, 0.00),
                  child: Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(25.0, 15.0, 25.0, 0.0),
                    child: Container(
                      width: MediaQuery.sizeOf(context).width * 1.0,
                      height: MediaQuery.sizeOf(context).height * 0.035,
                      decoration: BoxDecoration(
                        color: Color(0xFFE4E4E4),
                        boxShadow: [
                          BoxShadow(
                            blurRadius: 2.0,
                            color: Color(0x33000000),
                            offset: Offset(0.0, 1.0),
                          )
                        ],
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                15.0, 0.0, 0.0, 0.0),
                            child: Text(
                              'Experience',
                              style: FlutterFlowTheme.of(context)
                                  .labelLarge
                                  .override(
                                    fontFamily: 'Readex Pro',
                                    color: Colors.black,
                                    fontWeight: FontWeight.w600,
                                  ),
                            ),
                          ),
                          InkWell(
                            splashColor: Colors.transparent,
                            focusColor: Colors.transparent,
                            hoverColor: Colors.transparent,
                            highlightColor: Colors.transparent,
                            onTap: () async {
                              context.pushNamed('neweditprofile');
                            },
                            child: Container(
                              width: 40.0,
                              height: 40.0,
                              decoration: BoxDecoration(
                                color: Color(0xFFD7D7D7),
                                shape: BoxShape.circle,
                              ),
                              child: Align(
                                alignment: AlignmentDirectional(0.00, 0.00),
                                child: FaIcon(
                                  FontAwesomeIcons.pen,
                                  color: Colors.black,
                                  size: 15.0,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                if (valueOrDefault(currentUserDocument?.workExperience, '') !=
                        null &&
                    valueOrDefault(currentUserDocument?.workExperience, '') !=
                        '')
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(25.0, 10.0, 15.0, 0.0),
                    child: AuthUserStreamWidget(
                      builder: (context) => Column(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Align(
                            alignment: AlignmentDirectional(-1.00, 0.00),
                            child: Text(
                              'Working Experience',
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Readex Pro',
                                    fontSize: 10.0,
                                    fontWeight: FontWeight.bold,
                                  ),
                            ),
                          ),
                          Container(
                            width: MediaQuery.sizeOf(context).width * 0.85,
                            height: 100.0,
                            decoration: BoxDecoration(
                              color: FlutterFlowTheme.of(context)
                                  .secondaryBackground,
                            ),
                            child: SingleChildScrollView(
                              controller: _model.columnController3,
                              child: Column(
                                mainAxisSize: MainAxisSize.max,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        0.0, 10.0, 0.0, 0.0),
                                    child: Text(
                                      valueOrDefault(
                                          currentUserDocument?.workExperience,
                                          ''),
                                      textAlign: TextAlign.justify,
                                      maxLines: 30,
                                      style: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .override(
                                            fontFamily: 'Readex Pro',
                                            fontSize: 14.0,
                                            fontWeight: FontWeight.w300,
                                          ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                if (valueOrDefault(
                            currentUserDocument?.industryExperience, '') !=
                        null &&
                    valueOrDefault(
                            currentUserDocument?.industryExperience, '') !=
                        '')
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(25.0, 0.0, 15.0, 0.0),
                    child: AuthUserStreamWidget(
                      builder: (context) => Column(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Align(
                                alignment: AlignmentDirectional(-1.00, 0.00),
                                child: Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 25.0, 0.0, 0.0),
                                  child: Text(
                                    'Industrial Experience',
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Readex Pro',
                                          fontSize: 10.0,
                                          fontWeight: FontWeight.bold,
                                        ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Container(
                                width: MediaQuery.sizeOf(context).width * 0.85,
                                height: 100.0,
                                decoration: BoxDecoration(
                                  color: FlutterFlowTheme.of(context)
                                      .secondaryBackground,
                                ),
                                child: SingleChildScrollView(
                                  controller: _model.columnController4,
                                  child: Column(
                                    mainAxisSize: MainAxisSize.max,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            0.0, 10.0, 0.0, 0.0),
                                        child: Text(
                                          valueOrDefault(
                                              currentUserDocument
                                                  ?.industryExperience,
                                              ''),
                                          textAlign: TextAlign.justify,
                                          maxLines: 30,
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Readex Pro',
                                                fontSize: 14.0,
                                                fontWeight: FontWeight.w300,
                                              ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(15.0, 15.0, 15.0, 0.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Align(
                            alignment: AlignmentDirectional(-1.00, 0.00),
                            child: Container(
                              width: 100.0,
                              height: 25.0,
                              decoration: BoxDecoration(
                                color: FlutterFlowTheme.of(context)
                                    .secondaryBackground,
                              ),
                              child: Text(
                                'Snipe',
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Readex Pro',
                                      fontWeight: FontWeight.bold,
                                    ),
                              ),
                            ),
                          ),
                          InkWell(
                            splashColor: Colors.transparent,
                            focusColor: Colors.transparent,
                            hoverColor: Colors.transparent,
                            highlightColor: Colors.transparent,
                            onTap: () async {
                              await showModalBottomSheet(
                                isScrollControlled: true,
                                backgroundColor: Colors.transparent,
                                enableDrag: false,
                                context: context,
                                builder: (context) {
                                  return GestureDetector(
                                    onTap: () => _model
                                            .unfocusNode.canRequestFocus
                                        ? FocusScope.of(context)
                                            .requestFocus(_model.unfocusNode)
                                        : FocusScope.of(context).unfocus(),
                                    child: Padding(
                                      padding: MediaQuery.viewInsetsOf(context),
                                      child: NewsnipeimageWidget(),
                                    ),
                                  );
                                },
                              ).then((value) => safeSetState(() {}));
                            },
                            child: FaIcon(
                              FontAwesomeIcons.pen,
                              color: Colors.black,
                              size: 15.0,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(15.0, 0.0, 15.0, 0.0),
                      child: Container(
                        width: MediaQuery.sizeOf(context).width * 1.0,
                        height: 170.0,
                        decoration: BoxDecoration(
                          color:
                              FlutterFlowTheme.of(context).secondaryBackground,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 0.0, 0.0, 20.0),
                              child: InkWell(
                                splashColor: Colors.transparent,
                                focusColor: Colors.transparent,
                                hoverColor: Colors.transparent,
                                highlightColor: Colors.transparent,
                                onTap: () async {
                                  await _model.snipe?.animateTo(
                                    _model.snipe!.position.maxScrollExtent,
                                    duration: Duration(milliseconds: 1000),
                                    curve: Curves.ease,
                                  );
                                },
                                child: SingleChildScrollView(
                                  scrollDirection: Axis.horizontal,
                                  controller: _model.snipe,
                                  child: Row(
                                    mainAxisSize: MainAxisSize.max,
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            5.0, 0.0, 0.0, 0.0),
                                        child: Container(
                                          width: 90.0,
                                          height: 150.0,
                                          decoration: BoxDecoration(
                                            color: FlutterFlowTheme.of(context)
                                                .secondaryBackground,
                                          ),
                                          child: AuthUserStreamWidget(
                                            builder: (context) => ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(20.0),
                                              child: Image.network(
                                                valueOrDefault(
                                                    currentUserDocument
                                                        ?.snipeImage01,
                                                    ''),
                                                width: 300.0,
                                                height: 200.0,
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            5.0, 0.0, 0.0, 0.0),
                                        child: Container(
                                          width: 90.0,
                                          height: 150.0,
                                          decoration: BoxDecoration(
                                            color: FlutterFlowTheme.of(context)
                                                .secondaryBackground,
                                          ),
                                          child: AuthUserStreamWidget(
                                            builder: (context) => ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(20.0),
                                              child: Image.network(
                                                valueOrDefault(
                                                    currentUserDocument
                                                        ?.snipeImage02,
                                                    ''),
                                                width: 300.0,
                                                height: 200.0,
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            5.0, 0.0, 0.0, 0.0),
                                        child: Container(
                                          width: 90.0,
                                          height: 150.0,
                                          decoration: BoxDecoration(
                                            color: FlutterFlowTheme.of(context)
                                                .secondaryBackground,
                                          ),
                                          child: AuthUserStreamWidget(
                                            builder: (context) => ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(20.0),
                                              child: Image.network(
                                                valueOrDefault(
                                                    currentUserDocument
                                                        ?.snipeImage03,
                                                    ''),
                                                width: 300.0,
                                                height: 200.0,
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            5.0, 0.0, 5.0, 0.0),
                                        child: Container(
                                          width: 90.0,
                                          height: 150.0,
                                          decoration: BoxDecoration(
                                            color: FlutterFlowTheme.of(context)
                                                .secondaryBackground,
                                          ),
                                          child: AuthUserStreamWidget(
                                            builder: (context) => ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(20.0),
                                              child: Image.network(
                                                valueOrDefault(
                                                    currentUserDocument
                                                        ?.snipeImage04,
                                                    ''),
                                                width: 300.0,
                                                height: 200.0,
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            5.0, 0.0, 5.0, 0.0),
                                        child: Container(
                                          width: 90.0,
                                          height: 150.0,
                                          decoration: BoxDecoration(
                                            color: FlutterFlowTheme.of(context)
                                                .secondaryBackground,
                                          ),
                                          child: AuthUserStreamWidget(
                                            builder: (context) => ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(20.0),
                                              child: Image.network(
                                                valueOrDefault(
                                                    currentUserDocument
                                                        ?.snipeImage05,
                                                    ''),
                                                width: 300.0,
                                                height: 200.0,
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            5.0, 0.0, 5.0, 0.0),
                                        child: Container(
                                          width: 90.0,
                                          height: 150.0,
                                          decoration: BoxDecoration(
                                            color: FlutterFlowTheme.of(context)
                                                .secondaryBackground,
                                          ),
                                          child: AuthUserStreamWidget(
                                            builder: (context) => ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(20.0),
                                              child: Image.network(
                                                valueOrDefault(
                                                    currentUserDocument
                                                        ?.snipeImage06,
                                                    ''),
                                                width: 300.0,
                                                height: 200.0,
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            5.0, 0.0, 5.0, 0.0),
                                        child: Container(
                                          width: 90.0,
                                          height: 150.0,
                                          decoration: BoxDecoration(
                                            color: FlutterFlowTheme.of(context)
                                                .secondaryBackground,
                                          ),
                                          child: AuthUserStreamWidget(
                                            builder: (context) => ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(20.0),
                                              child: Image.network(
                                                valueOrDefault(
                                                    currentUserDocument
                                                        ?.snipeImage07,
                                                    ''),
                                                width: 300.0,
                                                height: 200.0,
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            5.0, 0.0, 5.0, 0.0),
                                        child: Container(
                                          width: 90.0,
                                          height: 150.0,
                                          decoration: BoxDecoration(
                                            color: FlutterFlowTheme.of(context)
                                                .secondaryBackground,
                                          ),
                                          child: AuthUserStreamWidget(
                                            builder: (context) => ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(20.0),
                                              child: Image.network(
                                                valueOrDefault(
                                                    currentUserDocument
                                                        ?.snipeImage08,
                                                    ''),
                                                width: 300.0,
                                                height: 200.0,
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            5.0, 0.0, 5.0, 0.0),
                                        child: Container(
                                          width: 90.0,
                                          height: 150.0,
                                          decoration: BoxDecoration(
                                            color: FlutterFlowTheme.of(context)
                                                .secondaryBackground,
                                          ),
                                          child: AuthUserStreamWidget(
                                            builder: (context) => ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(20.0),
                                              child: Image.network(
                                                valueOrDefault(
                                                    currentUserDocument
                                                        ?.snipeImage09,
                                                    ''),
                                                width: 300.0,
                                                height: 200.0,
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            5.0, 0.0, 5.0, 0.0),
                                        child: Container(
                                          width: 90.0,
                                          height: 150.0,
                                          decoration: BoxDecoration(
                                            color: FlutterFlowTheme.of(context)
                                                .secondaryBackground,
                                          ),
                                          child: AuthUserStreamWidget(
                                            builder: (context) => ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(20.0),
                                              child: Image.network(
                                                valueOrDefault(
                                                    currentUserDocument
                                                        ?.snipeImage10,
                                                    ''),
                                                width: 300.0,
                                                height: 200.0,
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Divider(
                              thickness: 1.0,
                              color: Color(0x4C000000),
                            ),
                          ],
                        ),
                      ),
                    ),
                    FFButtonWidget(
                      onPressed: () async {
                        context.pushNamed('viewPageSnipeImage');
                      },
                      text: 'View snipe ',
                      icon: Icon(
                        Icons.remove_red_eye_sharp,
                        size: 15.0,
                      ),
                      options: FFButtonOptions(
                        height: 25.0,
                        padding: EdgeInsetsDirectional.fromSTEB(
                            24.0, 0.0, 24.0, 0.0),
                        iconPadding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                        color: Color(0xFF008EFF),
                        textStyle:
                            FlutterFlowTheme.of(context).titleSmall.override(
                                  fontFamily: 'Readex Pro',
                                  color: Colors.white,
                                  fontSize: 10.0,
                                ),
                        elevation: 3.0,
                        borderSide: BorderSide(
                          color: Colors.transparent,
                          width: 1.0,
                        ),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 15.0, 0.0, 0.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Container(
                        width: MediaQuery.sizeOf(context).width * 1.0,
                        height: 100.0,
                        decoration: BoxDecoration(
                          color:
                              FlutterFlowTheme.of(context).secondaryBackground,
                          boxShadow: [
                            BoxShadow(
                              blurRadius: 4.0,
                              color: Color(0x33000000),
                              offset: Offset(0.0, 2.0),
                            )
                          ],
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            InkWell(
                              splashColor: Colors.transparent,
                              focusColor: Colors.transparent,
                              hoverColor: Colors.transparent,
                              highlightColor: Colors.transparent,
                              onTap: () async {
                                context.pushNamed(
                                  'postpage',
                                  extra: <String, dynamic>{
                                    kTransitionInfoKey: TransitionInfo(
                                      hasTransition: true,
                                      transitionType:
                                          PageTransitionType.topToBottom,
                                    ),
                                  },
                                );
                              },
                              child: Container(
                                width: MediaQuery.sizeOf(context).width * 1.0,
                                height: 120.0,
                                decoration: BoxDecoration(
                                  color: FlutterFlowTheme.of(context)
                                      .secondaryBackground,
                                  boxShadow: [
                                    BoxShadow(
                                      blurRadius: 3.0,
                                      color: Color(0x33000000),
                                      offset: Offset(0.0, 1.0),
                                    )
                                  ],
                                  borderRadius: BorderRadius.circular(0.0),
                                ),
                                child: Column(
                                  mainAxisSize: MainAxisSize.max,
                                  children: [
                                    Align(
                                      alignment:
                                          AlignmentDirectional(-1.00, 0.00),
                                      child: Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            15.0, 10.0, 0.0, 25.0),
                                        child: Text(
                                          'Posts',
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Readex Pro',
                                                fontWeight: FontWeight.bold,
                                              ),
                                        ),
                                      ),
                                    ),
                                    Padding(
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          10.0, 0.0, 0.0, 0.0),
                                      child: InkWell(
                                        splashColor: Colors.transparent,
                                        focusColor: Colors.transparent,
                                        hoverColor: Colors.transparent,
                                        highlightColor: Colors.transparent,
                                        onTap: () async {
                                          context.pushNamed('postpage');
                                        },
                                        child: Row(
                                          mainAxisSize: MainAxisSize.max,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              width: 40.0,
                                              height: 40.0,
                                              decoration: BoxDecoration(
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .secondaryBackground,
                                                shape: BoxShape.circle,
                                                border: Border.all(
                                                  color: Colors.black,
                                                  width: 0.3,
                                                ),
                                              ),
                                              child: AuthUserStreamWidget(
                                                builder: (context) => Container(
                                                  width: 40.0,
                                                  height: 40.0,
                                                  clipBehavior: Clip.antiAlias,
                                                  decoration: BoxDecoration(
                                                    shape: BoxShape.circle,
                                                  ),
                                                  child: Image.network(
                                                    currentUserPhoto,
                                                    fit: BoxFit.cover,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Opacity(
                                              opacity: 0.6,
                                              child: Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        25.0, 0.0, 0.0, 0.0),
                                                child: Text(
                                                  'whats on your mind?',
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .bodyMedium,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                SingleChildScrollView(
                  controller: _model.postfeed,
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      StreamBuilder<List<PostRecord>>(
                        stream: queryPostRecord(
                          parent: currentUserReference,
                          queryBuilder: (postRecord) => postRecord
                              .orderBy('time_posted', descending: true),
                        ),
                        builder: (context, snapshot) {
                          // Customize what your widget looks like when it's loading.
                          if (!snapshot.hasData) {
                            return Center(
                              child: SizedBox(
                                width: 50.0,
                                height: 50.0,
                                child: CircularProgressIndicator(
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                    FlutterFlowTheme.of(context).primary,
                                  ),
                                ),
                              ),
                            );
                          }
                          List<PostRecord> listViewPostRecordList =
                              snapshot.data!;
                          return ListView.builder(
                            padding: EdgeInsets.zero,
                            shrinkWrap: true,
                            scrollDirection: Axis.vertical,
                            itemCount: listViewPostRecordList.length,
                            itemBuilder: (context, listViewIndex) {
                              final listViewPostRecord =
                                  listViewPostRecordList[listViewIndex];
                              return Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    0.0, 20.0, 0.0, 0.0),
                                child: StreamBuilder<UserRecord>(
                                  stream: UserRecord.getDocument(
                                      listViewPostRecord.postUser!),
                                  builder: (context, snapshot) {
                                    // Customize what your widget looks like when it's loading.
                                    if (!snapshot.hasData) {
                                      return Center(
                                        child: SizedBox(
                                          width: 50.0,
                                          height: 50.0,
                                          child: CircularProgressIndicator(
                                            valueColor:
                                                AlwaysStoppedAnimation<Color>(
                                              FlutterFlowTheme.of(context)
                                                  .primary,
                                            ),
                                          ),
                                        ),
                                      );
                                    }
                                    final columnUserRecord = snapshot.data!;
                                    return Column(
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  15.0, 0.0, 15.0, 0.0),
                                          child: Row(
                                            mainAxisSize: MainAxisSize.max,
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Row(
                                                mainAxisSize: MainAxisSize.max,
                                                children: [
                                                  InkWell(
                                                    splashColor:
                                                        Colors.transparent,
                                                    focusColor:
                                                        Colors.transparent,
                                                    hoverColor:
                                                        Colors.transparent,
                                                    highlightColor:
                                                        Colors.transparent,
                                                    onTap: () async {
                                                      context.pushNamed(
                                                        'otheruserprofile',
                                                        queryParameters: {
                                                          'userinfo':
                                                              serializeParam(
                                                            listViewPostRecord
                                                                .postUser,
                                                            ParamType
                                                                .DocumentReference,
                                                          ),
                                                        }.withoutNulls,
                                                      );
                                                    },
                                                    child: Container(
                                                      width: 40.0,
                                                      height: 40.0,
                                                      decoration: BoxDecoration(
                                                        color: FlutterFlowTheme
                                                                .of(context)
                                                            .secondaryBackground,
                                                        boxShadow: [
                                                          BoxShadow(
                                                            blurRadius: 2.0,
                                                            color: Color(
                                                                0x33000000),
                                                            offset: Offset(
                                                                0.0, 1.0),
                                                          )
                                                        ],
                                                        shape: BoxShape.circle,
                                                      ),
                                                      child: Container(
                                                        width: 120.0,
                                                        height: 120.0,
                                                        clipBehavior:
                                                            Clip.antiAlias,
                                                        decoration:
                                                            BoxDecoration(
                                                          shape:
                                                              BoxShape.circle,
                                                        ),
                                                        child: Image.network(
                                                          columnUserRecord
                                                              .photoUrl,
                                                          fit: BoxFit.cover,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(25.0, 0.0,
                                                                0.0, 0.0),
                                                    child: Column(
                                                      mainAxisSize:
                                                          MainAxisSize.max,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        InkWell(
                                                          splashColor: Colors
                                                              .transparent,
                                                          focusColor: Colors
                                                              .transparent,
                                                          hoverColor: Colors
                                                              .transparent,
                                                          highlightColor: Colors
                                                              .transparent,
                                                          onTap: () async {
                                                            context.pushNamed(
                                                              'otheruserprofile',
                                                              queryParameters: {
                                                                'userinfo':
                                                                    serializeParam(
                                                                  listViewPostRecord
                                                                      .postUser,
                                                                  ParamType
                                                                      .DocumentReference,
                                                                ),
                                                              }.withoutNulls,
                                                            );
                                                          },
                                                          child: Text(
                                                            columnUserRecord
                                                                .displayName,
                                                            style: FlutterFlowTheme
                                                                    .of(context)
                                                                .titleMedium
                                                                .override(
                                                                  fontFamily:
                                                                      'Readex Pro',
                                                                  color: Color(
                                                                      0xFC000000),
                                                                  fontSize:
                                                                      15.0,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w600,
                                                                ),
                                                          ),
                                                        ),
                                                        InkWell(
                                                          splashColor: Colors
                                                              .transparent,
                                                          focusColor: Colors
                                                              .transparent,
                                                          hoverColor: Colors
                                                              .transparent,
                                                          highlightColor: Colors
                                                              .transparent,
                                                          onTap: () async {
                                                            context.pushNamed(
                                                              'singlepostview_feed_see',
                                                              queryParameters: {
                                                                'singlee':
                                                                    serializeParam(
                                                                  listViewPostRecord
                                                                      .reference,
                                                                  ParamType
                                                                      .DocumentReference,
                                                                ),
                                                              }.withoutNulls,
                                                            );
                                                          },
                                                          child: Text(
                                                            dateTimeFormat(
                                                                'relative',
                                                                listViewPostRecord
                                                                    .timePosted!),
                                                            style: FlutterFlowTheme
                                                                    .of(context)
                                                                .bodyMedium
                                                                .override(
                                                                  fontFamily:
                                                                      'Readex Pro',
                                                                  fontSize:
                                                                      10.0,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w300,
                                                                ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              Row(
                                                mainAxisSize: MainAxisSize.max,
                                                children: [
                                                  Padding(
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(0.0, 0.0,
                                                                10.0, 0.0),
                                                    child: InkWell(
                                                      splashColor:
                                                          Colors.transparent,
                                                      focusColor:
                                                          Colors.transparent,
                                                      hoverColor:
                                                          Colors.transparent,
                                                      highlightColor:
                                                          Colors.transparent,
                                                      onTap: () async {
                                                        await showModalBottomSheet(
                                                          isScrollControlled:
                                                              true,
                                                          backgroundColor:
                                                              Colors
                                                                  .transparent,
                                                          barrierColor: Colors
                                                              .transparent,
                                                          enableDrag: false,
                                                          context: context,
                                                          builder: (context) {
                                                            return GestureDetector(
                                                              onTap: () => _model
                                                                      .unfocusNode
                                                                      .canRequestFocus
                                                                  ? FocusScope.of(
                                                                          context)
                                                                      .requestFocus(
                                                                          _model
                                                                              .unfocusNode)
                                                                  : FocusScope.of(
                                                                          context)
                                                                      .unfocus(),
                                                              child: Padding(
                                                                padding: MediaQuery
                                                                    .viewInsetsOf(
                                                                        context),
                                                                child:
                                                                    Container(
                                                                  height: 550.0,
                                                                  child:
                                                                      PostsettingWidget(
                                                                    postdeleeee:
                                                                        listViewPostRecord
                                                                            .reference,
                                                                  ),
                                                                ),
                                                              ),
                                                            );
                                                          },
                                                        ).then((value) =>
                                                            safeSetState(
                                                                () {}));
                                                      },
                                                      child: Icon(
                                                        Icons.arrow_drop_down,
                                                        color:
                                                            listViewPostRecord
                                                                .iconColour,
                                                        size: 24.0,
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                        Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  15.0, 10.0, 15.0, 0.0),
                                          child: Row(
                                            mainAxisSize: MainAxisSize.max,
                                            children: [
                                              Expanded(
                                                child: Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          0.0, 0.0, 10.0, 0.0),
                                                  child: Text(
                                                    listViewPostRecord
                                                        .postTitle,
                                                    textAlign: TextAlign.start,
                                                    maxLines: 20,
                                                    style: FlutterFlowTheme.of(
                                                            context)
                                                        .bodyMedium
                                                        .override(
                                                          fontFamily:
                                                              'Readex Pro',
                                                          fontSize: 14.0,
                                                          lineHeight: 1.35,
                                                        ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  0.0, 0.0, 15.0, 0.0),
                                          child: Row(
                                            mainAxisSize: MainAxisSize.max,
                                            mainAxisAlignment:
                                                MainAxisAlignment.end,
                                            children: [
                                              InkWell(
                                                splashColor: Colors.transparent,
                                                focusColor: Colors.transparent,
                                                hoverColor: Colors.transparent,
                                                highlightColor:
                                                    Colors.transparent,
                                                onTap: () async {
                                                  context.pushNamed(
                                                    'singlepostview_feed_seemore',
                                                    queryParameters: {
                                                      'singlee': serializeParam(
                                                        listViewPostRecord
                                                            .reference,
                                                        ParamType
                                                            .DocumentReference,
                                                      ),
                                                    }.withoutNulls,
                                                  );
                                                },
                                                child: Text(
                                                  'See more',
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .bodyMedium
                                                      .override(
                                                        fontFamily:
                                                            'Readex Pro',
                                                        color:
                                                            Color(0x9714181B),
                                                      ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Stack(
                                          alignment:
                                              AlignmentDirectional(0.0, 0.0),
                                          children: [
                                            if (listViewPostRecord.postPhoto !=
                                                    null &&
                                                listViewPostRecord.postPhoto !=
                                                    '')
                                              Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        0.0, 10.0, 0.0, 0.0),
                                                child: InkWell(
                                                  splashColor:
                                                      Colors.transparent,
                                                  focusColor:
                                                      Colors.transparent,
                                                  hoverColor:
                                                      Colors.transparent,
                                                  highlightColor:
                                                      Colors.transparent,
                                                  onTap: () async {
                                                    context.pushNamed(
                                                      'singlepostview_feed_img',
                                                      queryParameters: {
                                                        'singlee':
                                                            serializeParam(
                                                          listViewPostRecord
                                                              .reference,
                                                          ParamType
                                                              .DocumentReference,
                                                        ),
                                                      }.withoutNulls,
                                                    );
                                                  },
                                                  child: ClipRRect(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            0.0),
                                                    child: Image.network(
                                                      listViewPostRecord
                                                          .postPhoto,
                                                      width: MediaQuery.sizeOf(
                                                                  context)
                                                              .width *
                                                          1.0,
                                                      fit: BoxFit.cover,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            if (listViewPostRecord.postCamera !=
                                                    null &&
                                                listViewPostRecord.postCamera !=
                                                    '')
                                              Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        0.0, 10.0, 0.0, 0.0),
                                                child: InkWell(
                                                  splashColor:
                                                      Colors.transparent,
                                                  focusColor:
                                                      Colors.transparent,
                                                  hoverColor:
                                                      Colors.transparent,
                                                  highlightColor:
                                                      Colors.transparent,
                                                  onTap: () async {
                                                    context.pushNamed(
                                                      'singlepostview_feed_cam',
                                                      queryParameters: {
                                                        'singlee':
                                                            serializeParam(
                                                          listViewPostRecord
                                                              .reference,
                                                          ParamType
                                                              .DocumentReference,
                                                        ),
                                                      }.withoutNulls,
                                                    );
                                                  },
                                                  child: ClipRRect(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            0.0),
                                                    child: Image.network(
                                                      listViewPostRecord
                                                          .postCamera,
                                                      width: MediaQuery.sizeOf(
                                                                  context)
                                                              .width *
                                                          1.0,
                                                      fit: BoxFit.cover,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            if (listViewPostRecord.postVideo !=
                                                    null &&
                                                listViewPostRecord.postVideo !=
                                                    '')
                                              Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        0.0, 10.0, 0.0, 0.0),
                                                child: FlutterFlowVideoPlayer(
                                                  path: listViewPostRecord
                                                      .postVideo,
                                                  videoType: VideoType.network,
                                                  autoPlay: false,
                                                  looping: true,
                                                  showControls: true,
                                                  allowFullScreen: true,
                                                  allowPlaybackSpeedMenu: false,
                                                ),
                                              ),
                                          ],
                                        ),
                                        Stack(
                                          alignment:
                                              AlignmentDirectional(-0.75, 0.0),
                                          children: [
                                            Padding(
                                              padding: EdgeInsetsDirectional
                                                  .fromSTEB(
                                                      15.0, 15.0, 15.0, 0.0),
                                              child: Row(
                                                mainAxisSize: MainAxisSize.max,
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  Row(
                                                    mainAxisSize:
                                                        MainAxisSize.max,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceBetween,
                                                    children: [
                                                      Padding(
                                                        padding:
                                                            EdgeInsetsDirectional
                                                                .fromSTEB(
                                                                    0.0,
                                                                    0.0,
                                                                    5.0,
                                                                    0.0),
                                                        child: Row(
                                                          mainAxisSize:
                                                              MainAxisSize.max,
                                                          children: [
                                                            FaIcon(
                                                              FontAwesomeIcons
                                                                  .handPeace,
                                                              color: FlutterFlowTheme
                                                                      .of(context)
                                                                  .secondaryText,
                                                              size: 20.0,
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                      Row(
                                                        mainAxisSize:
                                                            MainAxisSize.max,
                                                        children: [
                                                          Text(
                                                            listViewPostRecord
                                                                .postLikedBy
                                                                .length
                                                                .toString(),
                                                            style: FlutterFlowTheme
                                                                    .of(context)
                                                                .bodyMedium
                                                                .override(
                                                                  fontFamily:
                                                                      'Readex Pro',
                                                                  color: Colors
                                                                      .black,
                                                                  fontSize:
                                                                      12.0,
                                                                ),
                                                          ),
                                                        ],
                                                      ),
                                                    ],
                                                  ),
                                                  Row(
                                                    mainAxisSize:
                                                        MainAxisSize.max,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.end,
                                                    children: [
                                                      Padding(
                                                        padding:
                                                            EdgeInsetsDirectional
                                                                .fromSTEB(
                                                                    0.0,
                                                                    0.0,
                                                                    20.0,
                                                                    0.0),
                                                        child: Row(
                                                          mainAxisSize:
                                                              MainAxisSize.max,
                                                          children: [
                                                            Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          5.0,
                                                                          0.0),
                                                              child: Row(
                                                                mainAxisSize:
                                                                    MainAxisSize
                                                                        .max,
                                                                children: [
                                                                  StreamBuilder<
                                                                      List<
                                                                          CommentRecord>>(
                                                                    stream:
                                                                        queryCommentRecord(
                                                                      queryBuilder:
                                                                          (commentRecord) =>
                                                                              commentRecord.where(
                                                                        'post_type',
                                                                        isEqualTo:
                                                                            listViewPostRecord.reference,
                                                                      ),
                                                                    ),
                                                                    builder:
                                                                        (context,
                                                                            snapshot) {
                                                                      // Customize what your widget looks like when it's loading.
                                                                      if (!snapshot
                                                                          .hasData) {
                                                                        return Center(
                                                                          child:
                                                                              SizedBox(
                                                                            width:
                                                                                50.0,
                                                                            height:
                                                                                50.0,
                                                                            child:
                                                                                CircularProgressIndicator(
                                                                              valueColor: AlwaysStoppedAnimation<Color>(
                                                                                FlutterFlowTheme.of(context).primary,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        );
                                                                      }
                                                                      List<CommentRecord>
                                                                          commentcountCommentRecordList =
                                                                          snapshot
                                                                              .data!;
                                                                      return Text(
                                                                        commentcountCommentRecordList
                                                                            .length
                                                                            .toString(),
                                                                        style: FlutterFlowTheme.of(context)
                                                                            .bodyMedium
                                                                            .override(
                                                                              fontFamily: 'Readex Pro',
                                                                              color: Color(0xFF595959),
                                                                              fontSize: 12.0,
                                                                            ),
                                                                      );
                                                                    },
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            Row(
                                                              mainAxisSize:
                                                                  MainAxisSize
                                                                      .max,
                                                              children: [
                                                                InkWell(
                                                                  splashColor:
                                                                      Colors
                                                                          .transparent,
                                                                  focusColor: Colors
                                                                      .transparent,
                                                                  hoverColor: Colors
                                                                      .transparent,
                                                                  highlightColor:
                                                                      Colors
                                                                          .transparent,
                                                                  onTap:
                                                                      () async {
                                                                    await showModalBottomSheet(
                                                                      isScrollControlled:
                                                                          true,
                                                                      backgroundColor:
                                                                          Colors
                                                                              .transparent,
                                                                      enableDrag:
                                                                          false,
                                                                      context:
                                                                          context,
                                                                      builder:
                                                                          (context) {
                                                                        return GestureDetector(
                                                                          onTap: () => _model.unfocusNode.canRequestFocus
                                                                              ? FocusScope.of(context).requestFocus(_model.unfocusNode)
                                                                              : FocusScope.of(context).unfocus(),
                                                                          child:
                                                                              Padding(
                                                                            padding:
                                                                                MediaQuery.viewInsetsOf(context),
                                                                            child:
                                                                                CommentWidget(
                                                                              commentparameter: listViewPostRecord,
                                                                            ),
                                                                          ),
                                                                        );
                                                                      },
                                                                    ).then((value) =>
                                                                        safeSetState(
                                                                            () {}));
                                                                  },
                                                                  child: Text(
                                                                    'Comments',
                                                                    style: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .override(
                                                                          fontFamily:
                                                                              'Readex Pro',
                                                                          color:
                                                                              Colors.black,
                                                                          fontSize:
                                                                              12.0,
                                                                        ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                      Row(
                                                        mainAxisSize:
                                                            MainAxisSize.max,
                                                        children: [
                                                          Padding(
                                                            padding:
                                                                EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        0.0,
                                                                        0.0,
                                                                        5.0,
                                                                        0.0),
                                                            child: Row(
                                                              mainAxisSize:
                                                                  MainAxisSize
                                                                      .max,
                                                              children: [
                                                                Text(
                                                                  '124',
                                                                  style: FlutterFlowTheme.of(
                                                                          context)
                                                                      .bodyMedium
                                                                      .override(
                                                                        fontFamily:
                                                                            'Readex Pro',
                                                                        color: Color(
                                                                            0xFF595959),
                                                                        fontSize:
                                                                            12.0,
                                                                      ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Row(
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .max,
                                                            children: [
                                                              Text(
                                                                'Shares',
                                                                style: FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyMedium
                                                                    .override(
                                                                      fontFamily:
                                                                          'Readex Pro',
                                                                      color: Colors
                                                                          .black,
                                                                      fontSize:
                                                                          12.0,
                                                                    ),
                                                              ),
                                                            ],
                                                          ),
                                                        ],
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            ),
                                            if (listViewPostRecord.postLikedBy
                                                    .contains(
                                                        currentUserReference) ==
                                                true)
                                              FaIcon(
                                                FontAwesomeIcons.solidHandPeace,
                                                color: Color(0xFF0691FF),
                                                size: 25.0,
                                              ).animateOnActionTrigger(
                                                animationsMap[
                                                    'iconOnActionTriggerAnimation']!,
                                              ),
                                          ],
                                        ),
                                        Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  0.0, 10.0, 0.0, 0.0),
                                          child: Container(
                                            width: MediaQuery.sizeOf(context)
                                                    .width *
                                                1.0,
                                            height: 35.0,
                                            decoration: BoxDecoration(
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .secondaryBackground,
                                              border: Border.all(
                                                color: Color(0xA9000000),
                                                width: 0.5,
                                              ),
                                            ),
                                            child: Row(
                                              mainAxisSize: MainAxisSize.max,
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          25.0, 0.0, 0.0, 5.0),
                                                  child: InkWell(
                                                    splashColor:
                                                        Colors.transparent,
                                                    focusColor:
                                                        Colors.transparent,
                                                    hoverColor:
                                                        Colors.transparent,
                                                    highlightColor:
                                                        Colors.transparent,
                                                    onTap: () async {
                                                      if (animationsMap[
                                                              'iconOnActionTriggerAnimation'] !=
                                                          null) {
                                                        await animationsMap[
                                                                'iconOnActionTriggerAnimation']!
                                                            .controller
                                                            .forward(from: 0.0);
                                                      }
                                                    },
                                                    child: Row(
                                                      mainAxisSize:
                                                          MainAxisSize.max,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment.end,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .center,
                                                      children: [
                                                        Padding(
                                                          padding:
                                                              EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      10.0,
                                                                      0.0,
                                                                      0.0,
                                                                      0.0),
                                                          child: ToggleIcon(
                                                            onPressed:
                                                                () async {
                                                              final postLikedByElement =
                                                                  currentUserReference;
                                                              final postLikedByUpdate = listViewPostRecord
                                                                      .postLikedBy
                                                                      .contains(
                                                                          postLikedByElement)
                                                                  ? FieldValue
                                                                      .arrayRemove([
                                                                      postLikedByElement
                                                                    ])
                                                                  : FieldValue
                                                                      .arrayUnion([
                                                                      postLikedByElement
                                                                    ]);
                                                              await listViewPostRecord
                                                                  .reference
                                                                  .update({
                                                                ...mapToFirestore(
                                                                  {
                                                                    'post_liked_by':
                                                                        postLikedByUpdate,
                                                                  },
                                                                ),
                                                              });

                                                              await NotificationRecord
                                                                      .createDoc(
                                                                          listViewPostRecord
                                                                              .postUser!)
                                                                  .set(
                                                                      createNotificationRecordData(
                                                                userid:
                                                                    currentUserReference,
                                                                postid:
                                                                    listViewPostRecord
                                                                        .reference,
                                                                timestamp:
                                                                    getCurrentTimestamp,
                                                              ));
                                                            },
                                                            value: listViewPostRecord
                                                                .postLikedBy
                                                                .contains(
                                                                    currentUserReference),
                                                            onIcon: FaIcon(
                                                              FontAwesomeIcons
                                                                  .solidHandPeace,
                                                              color: Color(
                                                                  0xFF2C91DC),
                                                              size: 20.0,
                                                            ),
                                                            offIcon: FaIcon(
                                                              FontAwesomeIcons
                                                                  .handPeace,
                                                              color: Color(
                                                                  0xFC000000),
                                                              size: 20.0,
                                                            ),
                                                          ),
                                                        ),
                                                        Text(
                                                          'Like',
                                                          style: FlutterFlowTheme
                                                                  .of(context)
                                                              .bodyMedium,
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                                Row(
                                                  mainAxisSize:
                                                      MainAxisSize.max,
                                                  children: [
                                                    FFButtonWidget(
                                                      onPressed: () async {
                                                        await showModalBottomSheet(
                                                          isScrollControlled:
                                                              true,
                                                          backgroundColor:
                                                              Colors
                                                                  .transparent,
                                                          enableDrag: false,
                                                          context: context,
                                                          builder: (context) {
                                                            return GestureDetector(
                                                              onTap: () => _model
                                                                      .unfocusNode
                                                                      .canRequestFocus
                                                                  ? FocusScope.of(
                                                                          context)
                                                                      .requestFocus(
                                                                          _model
                                                                              .unfocusNode)
                                                                  : FocusScope.of(
                                                                          context)
                                                                      .unfocus(),
                                                              child: Padding(
                                                                padding: MediaQuery
                                                                    .viewInsetsOf(
                                                                        context),
                                                                child:
                                                                    CommentWidget(
                                                                  commentparameter:
                                                                      listViewPostRecord,
                                                                ),
                                                              ),
                                                            );
                                                          },
                                                        ).then((value) =>
                                                            safeSetState(
                                                                () {}));
                                                      },
                                                      text: 'Comment',
                                                      icon: FaIcon(
                                                        FontAwesomeIcons
                                                            .commentAlt,
                                                        color:
                                                            Color(0xA9000000),
                                                        size: 15.0,
                                                      ),
                                                      options: FFButtonOptions(
                                                        height: 27.0,
                                                        padding:
                                                            EdgeInsetsDirectional
                                                                .fromSTEB(
                                                                    0.0,
                                                                    0.0,
                                                                    0.0,
                                                                    0.0),
                                                        iconPadding:
                                                            EdgeInsetsDirectional
                                                                .fromSTEB(
                                                                    0.0,
                                                                    0.0,
                                                                    0.0,
                                                                    0.0),
                                                        color:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .primaryBtnText,
                                                        textStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .titleSmall
                                                                .override(
                                                                  fontFamily:
                                                                      'Readex Pro',
                                                                  color: Colors
                                                                      .black,
                                                                  fontSize:
                                                                      12.0,
                                                                ),
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(0.0),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                                Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          0.0, 0.0, 25.0, 0.0),
                                                  child: Row(
                                                    mainAxisSize:
                                                        MainAxisSize.max,
                                                    children: [
                                                      FFButtonWidget(
                                                        onPressed: () {
                                                          print(
                                                              'Button pressed ...');
                                                        },
                                                        text: 'Shares',
                                                        icon: FaIcon(
                                                          FontAwesomeIcons
                                                              .shareSquare,
                                                          color:
                                                              Color(0xA9000000),
                                                          size: 15.0,
                                                        ),
                                                        options:
                                                            FFButtonOptions(
                                                          height: 27.0,
                                                          padding:
                                                              EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      0.0,
                                                                      0.0,
                                                                      0.0,
                                                                      0.0),
                                                          iconPadding:
                                                              EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      0.0,
                                                                      0.0,
                                                                      0.0,
                                                                      0.0),
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .primaryBtnText,
                                                          textStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .titleSmall
                                                                  .override(
                                                                    fontFamily:
                                                                        'Readex Pro',
                                                                    color: Colors
                                                                        .black,
                                                                    fontSize:
                                                                        12.0,
                                                                  ),
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      0.0),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Divider(
                                          thickness: 4.0,
                                          color: Color(0xFF888888),
                                        ),
                                      ],
                                    );
                                  },
                                ),
                              );
                            },
                            controller: _model.listViewController,
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
