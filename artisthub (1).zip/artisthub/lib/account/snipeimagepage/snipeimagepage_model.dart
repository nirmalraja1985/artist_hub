import '/componant/newsnipeimage/newsnipeimage_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'snipeimagepage_widget.dart' show SnipeimagepageWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class SnipeimagepageModel extends FlutterFlowModel<SnipeimagepageWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // Model for newsnipeimage component.
  late NewsnipeimageModel newsnipeimageModel;

  /// Initialization and disposal methods.

  void initState(BuildContext context) {
    newsnipeimageModel = createModel(context, () => NewsnipeimageModel());
  }

  void dispose() {
    unfocusNode.dispose();
    newsnipeimageModel.dispose();
  }

  /// Action blocks are added here.

  /// Additional helper methods are added here.
}
