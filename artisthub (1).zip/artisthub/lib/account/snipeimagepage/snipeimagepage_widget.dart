import '/componant/newsnipeimage/newsnipeimage_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'snipeimagepage_model.dart';
export 'snipeimagepage_model.dart';

class SnipeimagepageWidget extends StatefulWidget {
  const SnipeimagepageWidget({Key? key}) : super(key: key);

  @override
  _SnipeimagepageWidgetState createState() => _SnipeimagepageWidgetState();
}

class _SnipeimagepageWidgetState extends State<SnipeimagepageWidget> {
  late SnipeimagepageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => SnipeimagepageModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () => _model.unfocusNode.canRequestFocus
          ? FocusScope.of(context).requestFocus(_model.unfocusNode)
          : FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: SafeArea(
          top: true,
          child: wrapWithModel(
            model: _model.newsnipeimageModel,
            updateCallback: () => setState(() {}),
            child: NewsnipeimageWidget(),
          ),
        ),
      ),
    );
  }
}
