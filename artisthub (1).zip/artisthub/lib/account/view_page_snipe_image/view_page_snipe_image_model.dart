import '/auth/firebase_auth/auth_util.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:styled_divider/styled_divider.dart';
import 'view_page_snipe_image_widget.dart' show ViewPageSnipeImageWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ViewPageSnipeImageModel
    extends FlutterFlowModel<ViewPageSnipeImageWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for snipe widget.
  ScrollController? snipe;

  /// Initialization and disposal methods.

  void initState(BuildContext context) {
    snipe = ScrollController();
  }

  void dispose() {
    unfocusNode.dispose();
    snipe?.dispose();
  }

  /// Action blocks are added here.

  /// Additional helper methods are added here.
}
