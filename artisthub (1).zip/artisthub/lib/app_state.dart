import 'package:flutter/material.dart';
import '/backend/backend.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {}

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  DateTime? _data2 = DateTime.fromMillisecondsSinceEpoch(1696154880000);
  DateTime? get data2 => _data2;
  set data2(DateTime? _value) {
    _data2 = _value;
  }

  List<String> _whatisyourservice = [
    'Free Services with Title Demand',
    'Negotiable',
    'Professional'
  ];
  List<String> get whatisyourservice => _whatisyourservice;
  set whatisyourservice(List<String> _value) {
    _whatisyourservice = _value;
  }

  void addToWhatisyourservice(String _value) {
    _whatisyourservice.add(_value);
  }

  void removeFromWhatisyourservice(String _value) {
    _whatisyourservice.remove(_value);
  }

  void removeAtIndexFromWhatisyourservice(int _index) {
    _whatisyourservice.removeAt(_index);
  }

  void updateWhatisyourserviceAtIndex(
    int _index,
    String Function(String) updateFn,
  ) {
    _whatisyourservice[_index] = updateFn(_whatisyourservice[_index]);
  }

  void insertAtIndexInWhatisyourservice(int _index, String _value) {
    _whatisyourservice.insert(_index, _value);
  }
}

LatLng? _latLngFromString(String? val) {
  if (val == null) {
    return null;
  }
  final split = val.split(',');
  final lat = double.parse(split.first);
  final lng = double.parse(split.last);
  return LatLng(lat, lng);
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}
