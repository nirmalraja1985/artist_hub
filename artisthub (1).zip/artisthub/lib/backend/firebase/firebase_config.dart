import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyCtCfd1uFnFvM1HOXmk8raXrLamR7YFG6s",
            authDomain: "artist-hub-6efa0.firebaseapp.com",
            projectId: "artist-hub-6efa0",
            storageBucket: "artist-hub-6efa0.appspot.com",
            messagingSenderId: "913126655251",
            appId: "1:913126655251:web:d7bd0e17f04aece13446e6",
            measurementId: "G-E0X3B1GTVS"));
  } else {
    await Firebase.initializeApp();
  }
}
