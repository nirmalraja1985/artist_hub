import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ReportProblemRecord extends FirestoreRecord {
  ReportProblemRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "report_id" field.
  String? _reportId;
  String get reportId => _reportId ?? '';
  bool hasReportId() => _reportId != null;

  // "problem_dropdown" field.
  String? _problemDropdown;
  String get problemDropdown => _problemDropdown ?? '';
  bool hasProblemDropdown() => _problemDropdown != null;

  // "title" field.
  String? _title;
  String get title => _title ?? '';
  bool hasTitle() => _title != null;

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "report" field.
  String? _report;
  String get report => _report ?? '';
  bool hasReport() => _report != null;

  // "screen_short" field.
  String? _screenShort;
  String get screenShort => _screenShort ?? '';
  bool hasScreenShort() => _screenShort != null;

  // "datetime" field.
  DateTime? _datetime;
  DateTime? get datetime => _datetime;
  bool hasDatetime() => _datetime != null;

  // "report_user" field.
  DocumentReference? _reportUser;
  DocumentReference? get reportUser => _reportUser;
  bool hasReportUser() => _reportUser != null;

  // "location" field.
  LatLng? _location;
  LatLng? get location => _location;
  bool hasLocation() => _location != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _reportId = snapshotData['report_id'] as String?;
    _problemDropdown = snapshotData['problem_dropdown'] as String?;
    _title = snapshotData['title'] as String?;
    _email = snapshotData['email'] as String?;
    _report = snapshotData['report'] as String?;
    _screenShort = snapshotData['screen_short'] as String?;
    _datetime = snapshotData['datetime'] as DateTime?;
    _reportUser = snapshotData['report_user'] as DocumentReference?;
    _location = snapshotData['location'] as LatLng?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('report_problem')
          : FirebaseFirestore.instance.collectionGroup('report_problem');

  static DocumentReference createDoc(DocumentReference parent) =>
      parent.collection('report_problem').doc();

  static Stream<ReportProblemRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ReportProblemRecord.fromSnapshot(s));

  static Future<ReportProblemRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ReportProblemRecord.fromSnapshot(s));

  static ReportProblemRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ReportProblemRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ReportProblemRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ReportProblemRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ReportProblemRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ReportProblemRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createReportProblemRecordData({
  String? reportId,
  String? problemDropdown,
  String? title,
  String? email,
  String? report,
  String? screenShort,
  DateTime? datetime,
  DocumentReference? reportUser,
  LatLng? location,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'report_id': reportId,
      'problem_dropdown': problemDropdown,
      'title': title,
      'email': email,
      'report': report,
      'screen_short': screenShort,
      'datetime': datetime,
      'report_user': reportUser,
      'location': location,
    }.withoutNulls,
  );

  return firestoreData;
}

class ReportProblemRecordDocumentEquality
    implements Equality<ReportProblemRecord> {
  const ReportProblemRecordDocumentEquality();

  @override
  bool equals(ReportProblemRecord? e1, ReportProblemRecord? e2) {
    return e1?.reportId == e2?.reportId &&
        e1?.problemDropdown == e2?.problemDropdown &&
        e1?.title == e2?.title &&
        e1?.email == e2?.email &&
        e1?.report == e2?.report &&
        e1?.screenShort == e2?.screenShort &&
        e1?.datetime == e2?.datetime &&
        e1?.reportUser == e2?.reportUser &&
        e1?.location == e2?.location;
  }

  @override
  int hash(ReportProblemRecord? e) => const ListEquality().hash([
        e?.reportId,
        e?.problemDropdown,
        e?.title,
        e?.email,
        e?.report,
        e?.screenShort,
        e?.datetime,
        e?.reportUser,
        e?.location
      ]);

  @override
  bool isValidKey(Object? o) => o is ReportProblemRecord;
}
