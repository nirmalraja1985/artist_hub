import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class StoryRecord extends FirestoreRecord {
  StoryRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "Userid" field.
  DocumentReference? _userid;
  DocumentReference? get userid => _userid;
  bool hasUserid() => _userid != null;

  // "storyimage" field.
  String? _storyimage;
  String get storyimage => _storyimage ?? '';
  bool hasStoryimage() => _storyimage != null;

  // "clicked" field.
  List<DocumentReference>? _clicked;
  List<DocumentReference> get clicked => _clicked ?? const [];
  bool hasClicked() => _clicked != null;

  // "createdTime" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _userid = snapshotData['Userid'] as DocumentReference?;
    _storyimage = snapshotData['storyimage'] as String?;
    _clicked = getDataList(snapshotData['clicked']);
    _createdTime = snapshotData['createdTime'] as DateTime?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('Story')
          : FirebaseFirestore.instance.collectionGroup('Story');

  static DocumentReference createDoc(DocumentReference parent) =>
      parent.collection('Story').doc();

  static Stream<StoryRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => StoryRecord.fromSnapshot(s));

  static Future<StoryRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => StoryRecord.fromSnapshot(s));

  static StoryRecord fromSnapshot(DocumentSnapshot snapshot) => StoryRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static StoryRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      StoryRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'StoryRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is StoryRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createStoryRecordData({
  DocumentReference? userid,
  String? storyimage,
  DateTime? createdTime,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'Userid': userid,
      'storyimage': storyimage,
      'createdTime': createdTime,
    }.withoutNulls,
  );

  return firestoreData;
}

class StoryRecordDocumentEquality implements Equality<StoryRecord> {
  const StoryRecordDocumentEquality();

  @override
  bool equals(StoryRecord? e1, StoryRecord? e2) {
    const listEquality = ListEquality();
    return e1?.userid == e2?.userid &&
        e1?.storyimage == e2?.storyimage &&
        listEquality.equals(e1?.clicked, e2?.clicked) &&
        e1?.createdTime == e2?.createdTime;
  }

  @override
  int hash(StoryRecord? e) => const ListEquality()
      .hash([e?.userid, e?.storyimage, e?.clicked, e?.createdTime]);

  @override
  bool isValidKey(Object? o) => o is StoryRecord;
}
