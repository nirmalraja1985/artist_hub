import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UserRecord extends FirestoreRecord {
  UserRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "display_name" field.
  String? _displayName;
  String get displayName => _displayName ?? '';
  bool hasDisplayName() => _displayName != null;

  // "photo_url" field.
  String? _photoUrl;
  String get photoUrl => _photoUrl ?? '';
  bool hasPhotoUrl() => _photoUrl != null;

  // "uid" field.
  String? _uid;
  String get uid => _uid ?? '';
  bool hasUid() => _uid != null;

  // "created_time" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "phone_number" field.
  String? _phoneNumber;
  String get phoneNumber => _phoneNumber ?? '';
  bool hasPhoneNumber() => _phoneNumber != null;

  // "bio" field.
  String? _bio;
  String get bio => _bio ?? '';
  bool hasBio() => _bio != null;

  // "cover_photo_url" field.
  String? _coverPhotoUrl;
  String get coverPhotoUrl => _coverPhotoUrl ?? '';
  bool hasCoverPhotoUrl() => _coverPhotoUrl != null;

  // "birthday" field.
  DateTime? _birthday;
  DateTime? get birthday => _birthday;
  bool hasBirthday() => _birthday != null;

  // "nationalty" field.
  String? _nationalty;
  String get nationalty => _nationalty ?? '';
  bool hasNationalty() => _nationalty != null;

  // "current_city" field.
  String? _currentCity;
  String get currentCity => _currentCity ?? '';
  bool hasCurrentCity() => _currentCity != null;

  // "home_town" field.
  String? _homeTown;
  String get homeTown => _homeTown ?? '';
  bool hasHomeTown() => _homeTown != null;

  // "home_phone_number" field.
  String? _homePhoneNumber;
  String get homePhoneNumber => _homePhoneNumber ?? '';
  bool hasHomePhoneNumber() => _homePhoneNumber != null;

  // "website" field.
  String? _website;
  String get website => _website ?? '';
  bool hasWebsite() => _website != null;

  // "facebook" field.
  String? _facebook;
  String get facebook => _facebook ?? '';
  bool hasFacebook() => _facebook != null;

  // "youtube" field.
  String? _youtube;
  String get youtube => _youtube ?? '';
  bool hasYoutube() => _youtube != null;

  // "college" field.
  String? _college;
  String get college => _college ?? '';
  bool hasCollege() => _college != null;

  // "high_school" field.
  String? _highSchool;
  String get highSchool => _highSchool ?? '';
  bool hasHighSchool() => _highSchool != null;

  // "univercity" field.
  String? _univercity;
  String get univercity => _univercity ?? '';
  bool hasUnivercity() => _univercity != null;

  // "edu_other" field.
  String? _eduOther;
  String get eduOther => _eduOther ?? '';
  bool hasEduOther() => _eduOther != null;

  // "work_experience" field.
  String? _workExperience;
  String get workExperience => _workExperience ?? '';
  bool hasWorkExperience() => _workExperience != null;

  // "industry_experience" field.
  String? _industryExperience;
  String get industryExperience => _industryExperience ?? '';
  bool hasIndustryExperience() => _industryExperience != null;

  // "snipe_image01" field.
  String? _snipeImage01;
  String get snipeImage01 => _snipeImage01 ?? '';
  bool hasSnipeImage01() => _snipeImage01 != null;

  // "snipe_image02" field.
  String? _snipeImage02;
  String get snipeImage02 => _snipeImage02 ?? '';
  bool hasSnipeImage02() => _snipeImage02 != null;

  // "snipe_image03" field.
  String? _snipeImage03;
  String get snipeImage03 => _snipeImage03 ?? '';
  bool hasSnipeImage03() => _snipeImage03 != null;

  // "snipe_image04" field.
  String? _snipeImage04;
  String get snipeImage04 => _snipeImage04 ?? '';
  bool hasSnipeImage04() => _snipeImage04 != null;

  // "snipe_image05" field.
  String? _snipeImage05;
  String get snipeImage05 => _snipeImage05 ?? '';
  bool hasSnipeImage05() => _snipeImage05 != null;

  // "snipe_image06" field.
  String? _snipeImage06;
  String get snipeImage06 => _snipeImage06 ?? '';
  bool hasSnipeImage06() => _snipeImage06 != null;

  // "snipe_image07" field.
  String? _snipeImage07;
  String get snipeImage07 => _snipeImage07 ?? '';
  bool hasSnipeImage07() => _snipeImage07 != null;

  // "snipe_image08" field.
  String? _snipeImage08;
  String get snipeImage08 => _snipeImage08 ?? '';
  bool hasSnipeImage08() => _snipeImage08 != null;

  // "snipe_image09" field.
  String? _snipeImage09;
  String get snipeImage09 => _snipeImage09 ?? '';
  bool hasSnipeImage09() => _snipeImage09 != null;

  // "snipe_image10" field.
  String? _snipeImage10;
  String get snipeImage10 => _snipeImage10 ?? '';
  bool hasSnipeImage10() => _snipeImage10 != null;

  // "following" field.
  List<DocumentReference>? _following;
  List<DocumentReference> get following => _following ?? const [];
  bool hasFollowing() => _following != null;

  // "Gender" field.
  String? _gender;
  String get gender => _gender ?? '';
  bool hasGender() => _gender != null;

  void _initializeFields() {
    _email = snapshotData['email'] as String?;
    _displayName = snapshotData['display_name'] as String?;
    _photoUrl = snapshotData['photo_url'] as String?;
    _uid = snapshotData['uid'] as String?;
    _createdTime = snapshotData['created_time'] as DateTime?;
    _phoneNumber = snapshotData['phone_number'] as String?;
    _bio = snapshotData['bio'] as String?;
    _coverPhotoUrl = snapshotData['cover_photo_url'] as String?;
    _birthday = snapshotData['birthday'] as DateTime?;
    _nationalty = snapshotData['nationalty'] as String?;
    _currentCity = snapshotData['current_city'] as String?;
    _homeTown = snapshotData['home_town'] as String?;
    _homePhoneNumber = snapshotData['home_phone_number'] as String?;
    _website = snapshotData['website'] as String?;
    _facebook = snapshotData['facebook'] as String?;
    _youtube = snapshotData['youtube'] as String?;
    _college = snapshotData['college'] as String?;
    _highSchool = snapshotData['high_school'] as String?;
    _univercity = snapshotData['univercity'] as String?;
    _eduOther = snapshotData['edu_other'] as String?;
    _workExperience = snapshotData['work_experience'] as String?;
    _industryExperience = snapshotData['industry_experience'] as String?;
    _snipeImage01 = snapshotData['snipe_image01'] as String?;
    _snipeImage02 = snapshotData['snipe_image02'] as String?;
    _snipeImage03 = snapshotData['snipe_image03'] as String?;
    _snipeImage04 = snapshotData['snipe_image04'] as String?;
    _snipeImage05 = snapshotData['snipe_image05'] as String?;
    _snipeImage06 = snapshotData['snipe_image06'] as String?;
    _snipeImage07 = snapshotData['snipe_image07'] as String?;
    _snipeImage08 = snapshotData['snipe_image08'] as String?;
    _snipeImage09 = snapshotData['snipe_image09'] as String?;
    _snipeImage10 = snapshotData['snipe_image10'] as String?;
    _following = getDataList(snapshotData['following']);
    _gender = snapshotData['Gender'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('user');

  static Stream<UserRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => UserRecord.fromSnapshot(s));

  static Future<UserRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => UserRecord.fromSnapshot(s));

  static UserRecord fromSnapshot(DocumentSnapshot snapshot) => UserRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static UserRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      UserRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'UserRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is UserRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createUserRecordData({
  String? email,
  String? displayName,
  String? photoUrl,
  String? uid,
  DateTime? createdTime,
  String? phoneNumber,
  String? bio,
  String? coverPhotoUrl,
  DateTime? birthday,
  String? nationalty,
  String? currentCity,
  String? homeTown,
  String? homePhoneNumber,
  String? website,
  String? facebook,
  String? youtube,
  String? college,
  String? highSchool,
  String? univercity,
  String? eduOther,
  String? workExperience,
  String? industryExperience,
  String? snipeImage01,
  String? snipeImage02,
  String? snipeImage03,
  String? snipeImage04,
  String? snipeImage05,
  String? snipeImage06,
  String? snipeImage07,
  String? snipeImage08,
  String? snipeImage09,
  String? snipeImage10,
  String? gender,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'email': email,
      'display_name': displayName,
      'photo_url': photoUrl,
      'uid': uid,
      'created_time': createdTime,
      'phone_number': phoneNumber,
      'bio': bio,
      'cover_photo_url': coverPhotoUrl,
      'birthday': birthday,
      'nationalty': nationalty,
      'current_city': currentCity,
      'home_town': homeTown,
      'home_phone_number': homePhoneNumber,
      'website': website,
      'facebook': facebook,
      'youtube': youtube,
      'college': college,
      'high_school': highSchool,
      'univercity': univercity,
      'edu_other': eduOther,
      'work_experience': workExperience,
      'industry_experience': industryExperience,
      'snipe_image01': snipeImage01,
      'snipe_image02': snipeImage02,
      'snipe_image03': snipeImage03,
      'snipe_image04': snipeImage04,
      'snipe_image05': snipeImage05,
      'snipe_image06': snipeImage06,
      'snipe_image07': snipeImage07,
      'snipe_image08': snipeImage08,
      'snipe_image09': snipeImage09,
      'snipe_image10': snipeImage10,
      'Gender': gender,
    }.withoutNulls,
  );

  return firestoreData;
}

class UserRecordDocumentEquality implements Equality<UserRecord> {
  const UserRecordDocumentEquality();

  @override
  bool equals(UserRecord? e1, UserRecord? e2) {
    const listEquality = ListEquality();
    return e1?.email == e2?.email &&
        e1?.displayName == e2?.displayName &&
        e1?.photoUrl == e2?.photoUrl &&
        e1?.uid == e2?.uid &&
        e1?.createdTime == e2?.createdTime &&
        e1?.phoneNumber == e2?.phoneNumber &&
        e1?.bio == e2?.bio &&
        e1?.coverPhotoUrl == e2?.coverPhotoUrl &&
        e1?.birthday == e2?.birthday &&
        e1?.nationalty == e2?.nationalty &&
        e1?.currentCity == e2?.currentCity &&
        e1?.homeTown == e2?.homeTown &&
        e1?.homePhoneNumber == e2?.homePhoneNumber &&
        e1?.website == e2?.website &&
        e1?.facebook == e2?.facebook &&
        e1?.youtube == e2?.youtube &&
        e1?.college == e2?.college &&
        e1?.highSchool == e2?.highSchool &&
        e1?.univercity == e2?.univercity &&
        e1?.eduOther == e2?.eduOther &&
        e1?.workExperience == e2?.workExperience &&
        e1?.industryExperience == e2?.industryExperience &&
        e1?.snipeImage01 == e2?.snipeImage01 &&
        e1?.snipeImage02 == e2?.snipeImage02 &&
        e1?.snipeImage03 == e2?.snipeImage03 &&
        e1?.snipeImage04 == e2?.snipeImage04 &&
        e1?.snipeImage05 == e2?.snipeImage05 &&
        e1?.snipeImage06 == e2?.snipeImage06 &&
        e1?.snipeImage07 == e2?.snipeImage07 &&
        e1?.snipeImage08 == e2?.snipeImage08 &&
        e1?.snipeImage09 == e2?.snipeImage09 &&
        e1?.snipeImage10 == e2?.snipeImage10 &&
        listEquality.equals(e1?.following, e2?.following) &&
        e1?.gender == e2?.gender;
  }

  @override
  int hash(UserRecord? e) => const ListEquality().hash([
        e?.email,
        e?.displayName,
        e?.photoUrl,
        e?.uid,
        e?.createdTime,
        e?.phoneNumber,
        e?.bio,
        e?.coverPhotoUrl,
        e?.birthday,
        e?.nationalty,
        e?.currentCity,
        e?.homeTown,
        e?.homePhoneNumber,
        e?.website,
        e?.facebook,
        e?.youtube,
        e?.college,
        e?.highSchool,
        e?.univercity,
        e?.eduOther,
        e?.workExperience,
        e?.industryExperience,
        e?.snipeImage01,
        e?.snipeImage02,
        e?.snipeImage03,
        e?.snipeImage04,
        e?.snipeImage05,
        e?.snipeImage06,
        e?.snipeImage07,
        e?.snipeImage08,
        e?.snipeImage09,
        e?.snipeImage10,
        e?.following,
        e?.gender
      ]);

  @override
  bool isValidKey(Object? o) => o is UserRecord;
}
