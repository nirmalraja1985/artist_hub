import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'profilepage_widget.dart' show ProfilepageWidget;
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:provider/provider.dart';

class ProfilepageModel extends FlutterFlowModel<ProfilepageWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for Column widget.
  ScrollController? columnController1;
  // State field(s) for Column widget.
  ScrollController? columnController2;
  // State field(s) for snipe widget.
  ScrollController? snipe;
  // State field(s) for feeds widget.
  ScrollController? feeds0;

  PagingController<DocumentSnapshot?, PostRecord>? feedsPagingController;
  Query? feedsPagingQuery;
  List<StreamSubscription?> feedsStreamSubscriptions = [];

  /// Initialization and disposal methods.

  void initState(BuildContext context) {
    columnController1 = ScrollController();
    columnController2 = ScrollController();
    snipe = ScrollController();
    feeds0 = ScrollController();
  }

  void dispose() {
    unfocusNode.dispose();
    columnController1?.dispose();
    columnController2?.dispose();
    snipe?.dispose();
    feeds0?.dispose();
    feedsStreamSubscriptions.forEach((s) => s?.cancel());
    feedsPagingController?.dispose();
  }

  /// Action blocks are added here.

  /// Additional helper methods are added here.

  PagingController<DocumentSnapshot?, PostRecord> setFeedsController(
    Query query, {
    DocumentReference<Object?>? parent,
  }) {
    feedsPagingController ??= _createFeedsController(query, parent);
    if (feedsPagingQuery != query) {
      feedsPagingQuery = query;
      feedsPagingController?.refresh();
    }
    return feedsPagingController!;
  }

  PagingController<DocumentSnapshot?, PostRecord> _createFeedsController(
    Query query,
    DocumentReference<Object?>? parent,
  ) {
    final controller =
        PagingController<DocumentSnapshot?, PostRecord>(firstPageKey: null);
    return controller
      ..addPageRequestListener(
        (nextPageMarker) => queryPostRecordPage(
          nextPageMarker: nextPageMarker,
          streamSubscriptions: feedsStreamSubscriptions,
          controller: controller,
          pageSize: 20,
          isStream: true,
        ),
      );
  }
}
