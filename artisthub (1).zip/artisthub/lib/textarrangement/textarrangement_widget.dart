import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'textarrangement_model.dart';
export 'textarrangement_model.dart';

class TextarrangementWidget extends StatefulWidget {
  const TextarrangementWidget({Key? key}) : super(key: key);

  @override
  _TextarrangementWidgetState createState() => _TextarrangementWidgetState();
}

class _TextarrangementWidgetState extends State<TextarrangementWidget> {
  late TextarrangementModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => TextarrangementModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () => _model.unfocusNode.canRequestFocus
          ? FocusScope.of(context).requestFocus(_model.unfocusNode)
          : FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).primary,
          automaticallyImplyLeading: false,
          title: Text(
            'Page Title',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  fontFamily: 'Outfit',
                  color: Colors.white,
                  fontSize: 22.0,
                ),
          ),
          actions: [
            FFButtonWidget(
              onPressed: () async {
                context.pushNamed('homepage');
              },
              text: 'home',
              options: FFButtonOptions(
                height: 40.0,
                padding: EdgeInsetsDirectional.fromSTEB(24.0, 0.0, 24.0, 0.0),
                iconPadding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                color: FlutterFlowTheme.of(context).primary,
                textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                      fontFamily: 'Readex Pro',
                      color: Colors.white,
                    ),
                elevation: 3.0,
                borderSide: BorderSide(
                  color: Colors.transparent,
                  width: 1.0,
                ),
                borderRadius: BorderRadius.circular(8.0),
              ),
            ),
          ],
          centerTitle: false,
          elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(15.0, 40.0, 15.0, 0.0),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    if (_model.isEditng)
                      SelectionArea(
                          child: Text(
                        'Education Minister Dr. Susil Premajayantha revealed that 4,718 principal appointments are scheduled for the beginning of November. This initiative aims to bolster the human and physical resources within the education system through the upcoming budget.\n\nDr. Premajayantha also outlined plans to address staff shortages in various services, with 705 vacancies to be filled in the Teacher Education Service and 405 vacancies in the Education Administration Service. The comprehensive goal is to resolve human resource deficiencies throughout the education system by January, emphasizing the need for everyone to adapt to the structural changes being implemented as part of educational transformation.\n\nIn a visionary move, the minister announced that, by 2030, all schools will offer free school lunches to students. He expressed a commitment to steadily increase allowances, including provisions for school uniforms and meals, beyond 2023, with ongoing discussions involving relevant parties, including the French government.\n\nDespite these transformative changes, Dr. Premajayantha stressed the importance of maintaining uninterrupted educational activities for children and called for the support of all stakeholders to ensure the sustainability of the education program.',
                        maxLines: 10,
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Readex Pro',
                              fontSize: 15.0,
                            ),
                      )),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
